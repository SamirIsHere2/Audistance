  // ---------------- App Connections page – Spotify ----------------
  // The connections page has its own Connect/Disconnect buttons that share
  // the same underlying Spotify state as the Sound page (where the master
  // connect/volume-link controls now live). Wired up via a helper called
  // once the main Spotify variables (below) exist.
  function wireConnectionsPageSpotify(){
    const connBtn        = document.getElementById('connSpotifyBtn');
    const connDisconnect = document.getElementById('connSpotifyDisconnectBtn');
    const connPre        = document.getElementById('connSpotifyPreConnect');
    const connPost       = document.getElementById('connSpotifyPostConnect');
    const connStatus     = document.getElementById('connSpotifyStatus');
    const connVolToggle  = document.getElementById('connSpotifyVolToggle');
    const connVolLabel   = document.getElementById('connSpotifyVolLabel');
    if(!connBtn) return;

    // Mirror whatever state the Sound-page Spotify connection is already in
    function syncConnPanel(){
      const connected = typeof spotifyAccessToken !== 'undefined' && spotifyAccessToken;
      connPre.style.display  = connected ? 'none' : 'block';
      connPost.style.display = connected ? 'block' : 'none';
    }
    syncConnPanel();
    if(typeof onSpotifyStateChange === 'function') onSpotifyStateChange(syncConnPanel);

    // Connect button – kicks off the same PKCE flow
    connBtn.addEventListener('click', () => startSpotifyAuth('connections'));

    // Disconnect
    connDisconnect.addEventListener('click', () => {
      document.getElementById('spotifyDisconnectBtn').click();
      syncConnPanel();
      connStatus.textContent = 'Disconnected.';
      connStatus.className = 'sp-status';
    });

    // Volume toggle mirrors the Sound page toggle
    connVolToggle.addEventListener('change', () => {
      const distToggle = document.getElementById('spotifyVolToggle');
      if(distToggle) distToggle.checked = connVolToggle.checked;
      if(connVolToggle.checked){
        const allow = document.getElementById('spotifyVolAllow');
        if(allow) allow.click();
      }
      connVolLabel.textContent = connVolToggle.checked ? 'Volume link on' : 'Volume link off';
    });
  }
