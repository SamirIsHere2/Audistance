  // ---------------- shared audio context ----------------
  let sharedCtx = null;
  function ensureSharedAudio(){
    if(!sharedCtx) sharedCtx = new (window.AudioContext || window.webkitAudioContext)();
    if(sharedCtx.state === 'suspended') sharedCtx.resume();
    return sharedCtx;
  }
