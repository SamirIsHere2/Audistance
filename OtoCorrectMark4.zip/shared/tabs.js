  // ---------------- tabs ----------------
  const tabNames = ['home','distance','sound','test','connections'];
  const tabs  = Object.fromEntries(tabNames.map(k => [k, document.getElementById('tab'+k[0].toUpperCase()+k.slice(1))]));
  const views = Object.fromEntries(tabNames.map(k => [k, document.getElementById('view-'+k)]));
  function showView(name){
    tabNames.forEach(k => {
      views[k].classList.toggle('active', k === name);
      tabs[k].classList.toggle('active', k === name);
    });
  }
  tabNames.forEach(k => tabs[k].addEventListener('click', () => showView(k)));

  // decorative hero equalizer bars
  (function buildHeroEqBars(){
    const container = document.getElementById('heroEqBars');
    if(!container) return;
    for(let i=0;i<22;i++){
      const bar = document.createElement('span');
      bar.style.height = (14 + Math.random()*46) + 'px';
      bar.style.animationDuration = (1.1 + Math.random()*1.3).toFixed(2) + 's';
      bar.style.animationDelay = '-' + (Math.random()*1.4).toFixed(2) + 's';
      container.appendChild(bar);
    }
  })();
  document.getElementById('heroStart').addEventListener('click', () => showView('distance'));
  document.getElementById('heroTest').addEventListener('click', () => showView('test'));
  document.querySelectorAll('[data-goto]').forEach(btn => {
    btn.addEventListener('click', () => showView(btn.getAttribute('data-goto')));
  });
