  // ---------------- tabs ----------------
  const tabs = {
    home:        document.getElementById('tabHome'),
    distance:    document.getElementById('tabDistance'),
    sound:       document.getElementById('tabSound'),
    test:        document.getElementById('tabTest'),
    connections: document.getElementById('tabConnections')
  };
  const views = {
    home:        document.getElementById('view-home'),
    distance:    document.getElementById('view-distance'),
    sound:       document.getElementById('view-sound'),
    test:        document.getElementById('view-test'),
    connections: document.getElementById('view-connections')
  };
  function showView(name){
    Object.keys(views).forEach(k => {
      views[k].classList.toggle('active', k === name);
      tabs[k].classList.toggle('active', k === name);
    });
  }
  Object.keys(tabs).forEach(k => tabs[k].addEventListener('click', () => showView(k)));

  document.getElementById('heroStart').addEventListener('click', () => showView('distance'));
  document.getElementById('heroTest').addEventListener('click', () => showView('test'));
  document.querySelectorAll('[data-goto]').forEach(btn => {
    btn.addEventListener('click', () => showView(btn.getAttribute('data-goto')));
  });

  // ---------------- interactive wave panel (visual only, no sound) ----------------
  (function initWaveInteractive(){
    const panel = document.querySelector('.wave-panel');
    const svg = panel ? panel.querySelector('.wave-panel-svg') : null;
    if(!panel || !svg) return;

    const paths = {
      1: svg.querySelector('.wave-1'),
      2: svg.querySelector('.wave-2'),
      3: svg.querySelector('.wave-3'),
      4: svg.querySelector('.wave-4')
    };

    // Rough sine approximations of each wave's resting shape (amplitude/
    // frequency/phase), used as the base curve that gets locally displaced
    // near the cursor — like pressing a finger into a taut string.
    const WAVES = [
      { el: paths[1], baseY: 150, amp: 55, freq: 4,    phase: 0 },
      { el: paths[2], baseY: 190, amp: 45, freq: 3.55, phase: 1.4 },
      { el: paths[3], baseY: 110, amp: 55, freq: 4,    phase: 2.6 },
      { el: paths[4], baseY: 230, amp: 28, freq: 3.2,  phase: 4.1 }
    ];

    const VIEW_W = 960, STEP = 12;
    let mouseX = null, mouseY = null;

    function waveYAt(cfg, x){
      return cfg.baseY + cfg.amp * Math.sin((x / VIEW_W) * Math.PI * 2 * cfg.freq + cfg.phase);
    }
    function bumpAt(x, baseY){
      if(mouseX === null) return 0;
      const dx = x - mouseX;
      const sigma = 70; // horizontal reach of the "touch"
      const gauss = Math.exp(-(dx*dx) / (2*sigma*sigma));
      const vertDist = Math.abs(mouseY - baseY);
      const vertFactor = Math.max(0, 1 - vertDist / 150); // fades out for waves far from the cursor
      const maxDisp = 46;
      const dir = mouseY < baseY ? 1 : -1; // push the line away from the cursor
      return dir * maxDisp * gauss * vertFactor;
    }

    function render(){
      WAVES.forEach(cfg => {
        if(!cfg.el) return;
        let d = '';
        for(let x = 0; x <= VIEW_W; x += STEP){
          const y = waveYAt(cfg, x) + bumpAt(x, cfg.baseY);
          d += (x === 0 ? 'M' : 'L') + x.toFixed(1) + ',' + y.toFixed(1) + ' ';
        }
        cfg.el.setAttribute('d', d);
      });
    }

    let rafScheduled = false;
    function scheduleRender(){
      if(rafScheduled) return;
      rafScheduled = true;
      requestAnimationFrame(() => { rafScheduled = false; render(); });
    }

    panel.addEventListener('mousemove', (e) => {
      const rect = svg.getBoundingClientRect();
      if(rect.width === 0 || rect.height === 0) return;
      mouseX = (e.clientX - rect.left) * (VIEW_W / rect.width);
      mouseY = (e.clientY - rect.top) * (320 / rect.height);
      scheduleRender();
    });
    panel.addEventListener('mouseleave', () => {
      mouseX = null; mouseY = null;
      scheduleRender();
    });

    render();
  })();

