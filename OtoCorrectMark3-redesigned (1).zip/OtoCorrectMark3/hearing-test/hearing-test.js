  // ================= HEARING TEST / AUDIOGRAM =================
  const TEST_FREQS = [250, 500, 1000, 2000, 4000, 8000];
  const STEP_SECONDS = 8;
  const DB_MIN = -10, DB_MAX = 120;

  const testIdle = document.getElementById('testIdle');
  const testSwitchEar = document.getElementById('testSwitchEar');
  const testRunning = document.getElementById('testRunning');
  const testResults = document.getElementById('testResults');
  const startTestBtn = document.getElementById('startTestBtn');
  const continueLeftBtn = document.getElementById('continueLeftBtn');
  const retakeTestBtn = document.getElementById('retakeTestBtn');
  const testEarLabel = document.getElementById('testEarLabel');
  const testFreqLabel = document.getElementById('testFreqLabel');
  const testSubLabel = document.getElementById('testSubLabel');
  const testProgressFill = document.getElementById('testProgressFill');
  const hearBtn = document.getElementById('hearBtn');
  const testStepCount = document.getElementById('testStepCount');
  const resultsSummary = document.getElementById('resultsSummary');
  const audiogramSvg = document.getElementById('audiogramSvg');
  const modeBothBtn = document.getElementById('modeBothBtn');
  const modeIndividualBtn = document.getElementById('modeIndividualBtn');
  const testModeDesc = document.getElementById('testModeDesc');

  const MODE_DESC = {
    both: 'One pass through all six tones, played to both ears at once — good for a quick, general check. Results plot as a single line.',
    individual: 'Tests each ear separately. Wear earbuds or headphones, and when prompted, make sure only the ear being tested can hear the tone (mute/remove the other side, or cover that ear). Results plot as two lines — right ear in red, left ear in blue.'
  };

  let testMode = 'both';
  modeBothBtn.addEventListener('click', () => setTestMode('both'));
  modeIndividualBtn.addEventListener('click', () => setTestMode('individual'));
  function setTestMode(mode){
    testMode = mode;
    modeBothBtn.classList.toggle('active', mode === 'both');
    modeIndividualBtn.classList.toggle('active', mode === 'individual');
    testModeDesc.textContent = MODE_DESC[mode];
  }

  let testCtx = null, testOsc = null, testGain = null;
  let testEar = 'both';
  let testStepIndex = 0;
  let testResultsData = { both: [], right: [], left: [] };
  let testStepStart = 0;
  let testRAF = null;
  let testStepDone = false;

  startTestBtn.addEventListener('click', beginTest);
  continueLeftBtn.addEventListener('click', beginLeftEar);
  retakeTestBtn.addEventListener('click', showTestOptions);
  hearBtn.addEventListener('click', onHeardClick);

  function showTestOptions(){
    testResults.style.display = 'none';
    testSwitchEar.style.display = 'none';
    testRunning.style.display = 'none';
    const wRunning = document.getElementById('wordRunning');
    const wResults = document.getElementById('wordResultsWrap');
    if(wRunning) wRunning.style.display = 'none';
    if(wResults) wResults.style.display = 'none';
    testIdle.style.display = 'block';
  }

  function beginTest(){
    testEar = testMode === 'both' ? 'both' : 'right';
    testStepIndex = 0;
    testResultsData = { both: [], right: [], left: [] };
    testIdle.style.display = 'none';
    testSwitchEar.style.display = 'none';
    testResults.style.display = 'none';
    testRunning.style.display = 'block';
    testCtx = ensureSharedAudio();
    const wRunning = document.getElementById('wordRunning');
    const wResults = document.getElementById('wordResultsWrap');
    if(wRunning) wRunning.style.display = 'none';
    if(wResults) wResults.style.display = 'none';
    requestMicPermissionOnce(); // ask once, up front, so the later word phase never re-prompts
    runStep();
  }

  function beginLeftEar(){
    testEar = 'left';
    testStepIndex = 0;
    testSwitchEar.style.display = 'none';
    testRunning.style.display = 'block';
    runStep();
  }

  function runStep(){
    if(testStepIndex >= TEST_FREQS.length){
      if(testEar === 'right'){
        testRunning.style.display = 'none';
        testSwitchEar.style.display = 'block';
      } else {
        finishTest();
      }
      return;
    }
    testStepDone = false;
    const freq = TEST_FREQS[testStepIndex];
    testEarLabel.textContent = testEar === 'both' ? 'Both ears' : (testEar === 'right' ? 'Right ear' : 'Left ear');
    testFreqLabel.textContent = freq + ' Hz';
    testSubLabel.textContent = testEar === 'both'
      ? 'Listen closely — it starts quiet and gets louder…'
      : 'Make sure only your ' + testEar + ' ear can hear this — it starts quiet and gets louder…';
    testStepCount.textContent = 'Step ' + (testStepIndex+1) + ' of ' + TEST_FREQS.length;
    testProgressFill.style.width = '0%';

    stopTestTone();
    testOsc = testCtx.createOscillator();
    testGain = testCtx.createGain();
    testOsc.type = 'sine';
    testOsc.frequency.value = freq;
    testGain.gain.setValueAtTime(0.0001, testCtx.currentTime);
    testGain.gain.linearRampToValueAtTime(0.5, testCtx.currentTime + STEP_SECONDS);
    testOsc.connect(testGain);
    testGain.connect(testCtx.destination);
    testOsc.start();

    testStepStart = performance.now();
    tickStep();
  }

  function tickStep(){
    if(testStepDone) return;
    const elapsed = (performance.now() - testStepStart) / 1000;
    const pct = Math.min(100, (elapsed / STEP_SECONDS) * 100);
    testProgressFill.style.width = pct + '%';
    if(elapsed >= STEP_SECONDS){
      recordStep(1.0, false);
      return;
    }
    testRAF = requestAnimationFrame(tickStep);
  }

  function onHeardClick(){
    if(testStepDone) return;
    const elapsed = (performance.now() - testStepStart) / 1000;
    const frac = Math.max(0.02, Math.min(1, elapsed / STEP_SECONDS));
    recordStep(frac, true);
  }

  function recordStep(frac, heard){
    testStepDone = true;
    if(testRAF) cancelAnimationFrame(testRAF);
    stopTestTone();
    const db = DB_MIN + frac * (DB_MAX - DB_MIN);
    testResultsData[testEar].push({ freq: TEST_FREQS[testStepIndex], db: db, heard: heard });
    testStepIndex++;
    setTimeout(runStep, 350);
  }

  function stopTestTone(){
    if(testOsc){
      try{ testOsc.stop(); }catch(e){}
      try{ testOsc.disconnect(); }catch(e){}
      testOsc = null;
    }
    if(testGain){
      try{ testGain.disconnect(); }catch(e){}
      testGain = null;
    }
  }

  function finishTest(){
    testRunning.style.display = 'none';
    if(testMode === 'both'){
      const heard = testResultsData.both.filter(r => r.heard).length;
      resultsSummary.textContent = 'Detected ' + heard + ' of ' + TEST_FREQS.length + ' tones. Lower on the chart means a tone had to get louder before you noticed it at that frequency.';
    } else {
      const rightHeard = testResultsData.right.filter(r => r.heard).length;
      const leftHeard = testResultsData.left.filter(r => r.heard).length;
      resultsSummary.textContent = 'Right ear: detected ' + rightHeard + ' of ' + TEST_FREQS.length + ' tones. Left ear: detected ' + leftHeard + ' of ' + TEST_FREQS.length + ' tones. Lower on the chart means a tone had to get louder before you noticed it at that frequency.';
    }
    drawAudiogram(testMode, testResultsData);
    // Tone portion is done — continue straight into the spoken-word portion.
    // Full results (tones + words) only appear once the word phase finishes too.
    beginWordTest();
  }

  function revealCombinedResults(){
    testResults.style.display = 'block';
  }

  function drawAudiogram(mode, results){
    const W = 900, H = 480;
    const padL = 70, padR = 150, padT = 90, padB = 30;
    const chartW = W - padL - padR, chartH = H - padT - padB;
    const n = TEST_FREQS.length;
    const xFor = i => padL + (chartW * (i + 0.5) / n);
    const yFor = db => padT + ((db - DB_MIN) / (DB_MAX - DB_MIN)) * chartH;
    const RED = '#D8493D', BLUE = '#2E9BE0', BOTH_COLOR = '#6C3FC5';

    const bands = [
      { label:'Normal\nHearing', from:-10, to:20,  shade:'#FFFFFF' },
      { label:'Mild',            from:20,  to:40,  shade:'#F6F6F6' },
      { label:'Moderate',        from:40,  to:55,  shade:'#ECECEC' },
      { label:'Moderately\nSevere', from:55, to:70, shade:'#E2E2E2' },
      { label:'Severe',          from:70,  to:90,  shade:'#D7D7D7' },
      { label:'Profound',        from:90,  to:120, shade:'#CBCBCB' }
    ];

    let svg = '';

    // title + legend
    svg += '<text x="'+padL+'" y="34" font-size="26" font-weight="700" fill="'+BLUE+'" font-family="Space Grotesk, sans-serif">Pure Tone Audiogram</text>';
    if(mode === 'both'){
      svg += '<circle cx="'+(W-140)+'" cy="34" r="6" fill="none" stroke="'+BOTH_COLOR+'" stroke-width="2.5"/>';
      svg += '<text x="'+(W-125)+'" y="39" font-size="13" font-weight="600" fill="'+BOTH_COLOR+'" font-family="IBM Plex Sans, sans-serif">Both Ears</text>';
    } else {
      svg += '<circle cx="'+(W-140)+'" cy="26" r="6" fill="none" stroke="'+RED+'" stroke-width="2.5"/>';
      svg += '<text x="'+(W-125)+'" y="31" font-size="13" font-weight="600" fill="'+RED+'" font-family="IBM Plex Sans, sans-serif">Right Ear</text>';
      svg += '<g transform="translate('+(W-140)+',48)"><line x1="-5" y1="-5" x2="5" y2="5" stroke="'+BLUE+'" stroke-width="2.5"/><line x1="-5" y1="5" x2="5" y2="-5" stroke="'+BLUE+'" stroke-width="2.5"/></g>';
      svg += '<text x="'+(W-125)+'" y="53" font-size="13" font-weight="600" fill="'+BLUE+'" font-family="IBM Plex Sans, sans-serif">Left Ear</text>';
    }

    // frequency axis label + values
    svg += '<text x="'+padL+'" y="64" font-size="13" font-style="italic" font-weight="600" fill="#241B35" font-family="IBM Plex Sans, sans-serif">Frequency (Hz)</text>';
    TEST_FREQS.forEach((f,i) => {
      svg += '<text x="'+xFor(i)+'" y="80" font-size="13" font-weight="600" fill="#241B35" text-anchor="middle" font-family="IBM Plex Sans, sans-serif">'+f+'</text>';
    });

    // volume axis label (rotated)
    svg += '<text x="18" y="'+(padT+chartH/2)+'" font-size="13" font-style="italic" font-weight="600" fill="#241B35" text-anchor="middle" font-family="IBM Plex Sans, sans-serif" transform="rotate(-90 18 '+(padT+chartH/2)+')">Volume (dB)</text>';

    // severity band shading
    bands.forEach(b => {
      svg += '<rect x="'+padL+'" y="'+yFor(b.to)+'" width="'+chartW+'" height="'+(yFor(b.from)-yFor(b.to))+'" fill="'+b.shade+'"/>';
    });

    // horizontal gridlines + dB labels
    for(let db = DB_MIN; db <= DB_MAX; db += 10){
      const y = yFor(db);
      svg += '<line x1="'+padL+'" y1="'+y+'" x2="'+(padL+chartW)+'" y2="'+y+'" stroke="#B8B8B8" stroke-width="1"/>';
      svg += '<text x="'+(padL-12)+'" y="'+(y+4)+'" font-size="12" fill="#241B35" text-anchor="end" font-family="IBM Plex Mono, monospace">'+db+'</text>';
    }
    // vertical gridlines
    for(let i=0;i<=n;i++){
      const x = padL + (chartW*i/n);
      svg += '<line x1="'+x+'" y1="'+padT+'" x2="'+x+'" y2="'+(padT+chartH)+'" stroke="#B8B8B8" stroke-width="1"/>';
    }
    // chart border
    svg += '<rect x="'+padL+'" y="'+padT+'" width="'+chartW+'" height="'+chartH+'" fill="none" stroke="#8A8A8A" stroke-width="1.5"/>';

    // right-side severity tick marks + labels
    bands.forEach(b => {
      const yMid = (yFor(b.from)+yFor(b.to))/2;
      const lines = b.label.split('\n');
      lines.forEach((ln,li) => {
        svg += '<text x="'+(padL+chartW+18)+'" y="'+(yMid + li*15 - (lines.length-1)*7)+'" font-size="13" font-weight="600" fill="#241B35" font-family="IBM Plex Sans, sans-serif">'+ln+'</text>';
      });
    });
    for(let i=1;i<bands.length;i++){
      const yTick = yFor(bands[i].from);
      svg += '<line x1="'+(padL+chartW)+'" y1="'+yTick+'" x2="'+(padL+chartW+8)+'" y2="'+yTick+'" stroke="#8A8A8A" stroke-width="1.5"/>';
    }

    function plotEar(data, color, symbol){
      if(!data || data.length === 0) return;
      let points = [];
      data.forEach((d,i) => {
        const x = xFor(i);
        const y = yFor(d.db);
        points.push(x+','+y);
      });
      svg += '<polyline points="'+points.join(' ')+'" fill="none" stroke="'+color+'" stroke-width="2"/>';
      data.forEach((d,i) => {
        const x = xFor(i);
        const y = yFor(d.db);
        if(symbol === 'circle'){
          svg += '<circle cx="'+x+'" cy="'+y+'" r="7" fill="#fff" stroke="'+color+'" stroke-width="2.5"/>';
        } else {
          svg += '<g transform="translate('+x+','+y+')"><line x1="-6" y1="-6" x2="6" y2="6" stroke="'+color+'" stroke-width="2.5"/><line x1="-6" y1="6" x2="6" y2="-6" stroke="'+color+'" stroke-width="2.5"/></g>';
        }
        if(!d.heard){
          svg += '<line x1="'+x+'" y1="'+(y+9)+'" x2="'+x+'" y2="'+(y+20)+'" stroke="'+color+'" stroke-width="2"/>';
          svg += '<polygon points="'+(x-4)+','+(y+16)+' '+(x+4)+','+(y+16)+' '+x+','+(y+22)+'" fill="'+color+'"/>';
        }
      });
    }

    if(mode === 'both'){
      plotEar(results.both, BOTH_COLOR, 'circle');
    } else {
      plotEar(results.right, RED, 'circle');
      plotEar(results.left, BLUE, 'x');
    }

    audiogramSvg.innerHTML = svg;
  }

  // ================= WORD REPETITION CHECK =================
  // This is the second half of the same test — it starts automatically once
  // the tone portion finishes. The word itself is never shown on screen; it's
  // spoken aloud (text-to-speech) at one of several volume levels, and the
  // person just says back what they heard.
  const WORD_LIST_SETS = {
    en: ['cat','ball','shoe','tree','cup','fish','book','star','moon','frog'],
    es: ['gato','pelota','zapato','árbol','taza','pez','libro','estrella','luna','rana'],
    zh: ['猫','球','鞋','树','杯子','鱼','书','星星','月亮','青蛙']
  };
  const LANG_LOCALES = { en: 'en-US', es: 'es-ES', zh: 'zh-CN' };
  let wordLang = 'en';
  let WORD_LIST = WORD_LIST_SETS[wordLang];

  const wordLangToggle = document.getElementById('wordLangToggle');
  const wordLangOtherBtn = document.getElementById('wordLangOtherBtn');
  const wordLangOtherRow = document.getElementById('wordLangOtherRow');
  const wordLangOtherInput = document.getElementById('wordLangOtherInput');
  const wordLangOtherSubmit = document.getElementById('wordLangOtherSubmit');
  const wordLangOtherStatus = document.getElementById('wordLangOtherStatus');

  // Covers the English/Spanish cards inside #wordLangToggle as well as the
  // 中文 quick-chip that lives inside the "+" reveal row.
  document.querySelectorAll('[data-lang]').forEach(btn => {
    btn.addEventListener('click', () => {
      wordLang = btn.getAttribute('data-lang');
      document.querySelectorAll('[data-lang]').forEach(b => b.classList.toggle('active', b === btn));
    });
  });

  wordLangOtherBtn.addEventListener('click', () => {
    const showing = wordLangOtherRow.style.display !== 'none';
    wordLangOtherRow.style.display = showing ? 'none' : 'block';
    if(!showing) wordLangOtherInput.focus();
  });

  wordLangOtherSubmit.addEventListener('click', async () => {
    const requested = wordLangOtherInput.value.trim();
    if(!requested){
      wordLangOtherStatus.textContent = 'Type a language name first.';
      return;
    }
    wordLangOtherSubmit.disabled = true;
    wordLangOtherStatus.textContent = 'Sending…';
    try{
      if(typeof window.submitLanguageRequest === 'function'){
        await window.submitLanguageRequest(requested);
      }
      wordLangOtherStatus.textContent = 'Thanks — we\'ve sent "' + requested + '" to the team to consider for a future update.';
      wordLangOtherInput.value = '';
    }catch(e){
      wordLangOtherStatus.textContent = 'Couldn\'t send that just now — please try again later.';
    }
    wordLangOtherSubmit.disabled = false;
  });

  const WORD_VOLUME_LEVELS = [
    { label: 'Loud',  volume: 1.0  },
    { label: 'Medium', volume: 0.55 },
    { label: 'Soft',   volume: 0.22 }
  ];
  const wordRunning = document.getElementById('wordRunning');
  const wordResultsWrap = document.getElementById('wordResultsWrap');
  const wordStepCount = document.getElementById('wordStepCount');
  const wordLevelLabel = document.getElementById('wordLevelLabel');
  const wordStatus = document.getElementById('wordStatus');
  const wordProgressFill = document.getElementById('wordProgressFill');
  const wordSkipBtn = document.getElementById('wordSkipBtn');
  const wordAccuracySummary = document.getElementById('wordAccuracySummary');
  const wordTableBody = document.getElementById('wordTableBody');

  let wordIndex = 0;
  let wordRecords = [];
  let speechSupported = !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  let ttsSupported = 'speechSynthesis' in window;

  // ---- one-time microphone permission, held open for the whole test ----
  // getUserMedia is only ever called once (here). We keep the resulting
  // stream open for the duration of the word test instead of stopping it
  // right away — on most browsers that's what keeps the mic "already on"
  // so each new SpeechRecognition() reuses the same grant silently instead
  // of prompting again per word. The stream is released once the whole
  // word test is done (finishWordTest) or the test is restarted.
  let micPermissionState = 'unrequested'; // 'unrequested' | 'granted' | 'denied'
  let micPermissionPromise = null;
  let micStream = null;
  function requestMicPermissionOnce(){
    if(!speechSupported) return Promise.resolve(false);
    if(micPermissionPromise) return micPermissionPromise;
    micPermissionPromise = navigator.mediaDevices.getUserMedia({ audio: true })
      .then(stream => {
        micStream = stream; // keep tracks open — released when the word test ends
        micPermissionState = 'granted';
        return true;
      })
      .catch(() => {
        micPermissionState = 'denied';
        return false;
      });
    return micPermissionPromise;
  }
  function releaseMicStream(){
    if(micStream){
      micStream.getTracks().forEach(t => t.stop());
      micStream = null;
    }
  }

  // A fresh recognition instance per word — reusing one object across words
  // risks a race where start() fires before the previous instance has fully
  // stopped, which can cut a listen short. This still only asks for mic
  // permission once overall, because that grant is tied to the persistent
  // micStream above, not to how many SpeechRecognition objects get created.
  let wordRecognition = null;
  function newRecognition(){
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SR();
    rec.lang = LANG_LOCALES[wordLang] || 'en-US';
    rec.maxAlternatives = 3;
    rec.interimResults = false;
    rec.continuous = false;
    return rec;
  }

  wordSkipBtn.addEventListener('click', () => recordWord('(skipped)', false));

  function beginWordTest(){
    WORD_LIST = WORD_LIST_SETS[wordLang] || WORD_LIST_SETS.en;
    wordIndex = 0;
    wordRecords = [];
    wordResultsWrap.style.display = 'none';
    testRunning.style.display = 'none';
    wordRunning.style.display = 'block';
    runWordStep();
  }

  function currentLevel(){
    return WORD_VOLUME_LEVELS[wordIndex % WORD_VOLUME_LEVELS.length];
  }

  function runWordStep(){
    if(wordIndex >= WORD_LIST.length){
      finishWordTest();
      return;
    }
    const word = WORD_LIST[wordIndex];
    const level = currentLevel();
    wordStepCount.textContent = 'Word ' + (wordIndex+1) + ' of ' + WORD_LIST.length;
    wordLevelLabel.textContent = '🔊';
    wordProgressFill.style.width = '0%';

    if(!ttsSupported){
      // No speech synthesis available at all — fall back to showing the word,
      // since there's no other way to convey it without one.
      wordLevelLabel.textContent = word;
      wordStatus.textContent = 'Text-to-speech isn\'t supported in this browser — say the word above out loud.';
      afterWordCue(word);
      return;
    }

    wordStatus.textContent = 'Playing a word at ' + level.label.toLowerCase() + ' volume — listen closely…';
    wordProgressFill.style.width = '100%';
    speakWord(word, level.volume).then(() => {
      afterWordCue(word);
    });
  }

  // Speech-synthesis voices load asynchronously in some browsers. We use
  // this only to tell the person if their device likely has no voice
  // installed for the chosen language — we do NOT force-assign a specific
  // voice object onto the utterance, because pairing a cached voice with
  // utter.lang can cause some browsers (notably Chrome) to silently drop
  // the utterance entirely instead of speaking it. Setting utter.lang alone
  // is enough for the browser to pick an appropriate voice itself.
  let cachedVoices = [];
  function loadVoices(){
    cachedVoices = window.speechSynthesis ? window.speechSynthesis.getVoices() : [];
    return cachedVoices;
  }
  loadVoices();
  if(window.speechSynthesis){
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }
  function hasVoiceForLocale(locale){
    if(!cachedVoices.length) loadVoices();
    const langPrefix = locale.split('-')[0].toLowerCase();
    return cachedVoices.some(v => v.lang && v.lang.toLowerCase().startsWith(langPrefix));
  }

  function speakWord(word, volume){
    const locale = LANG_LOCALES[wordLang] || 'en-US';
    return new Promise((resolve) => {
      try{
        window.speechSynthesis.cancel(); // clear any queued/stuck utterances
        const utter = new SpeechSynthesisUtterance(word);
        utter.lang = locale;
        utter.rate = 0.9;
        utter.volume = Math.max(0, Math.min(1, volume));
        utter.onend = resolve;
        utter.onerror = resolve;
        if(wordLang !== 'en' && !hasVoiceForLocale(locale)){
          // No matching voice installed for this language — say so plainly
          // rather than leaving it a silent mystery if it sounds off.
          wordStatus.textContent = 'No ' + (wordLang === 'es' ? 'Spanish' : 'Mandarin') + ' voice may be installed on this device, so pronunciation may be off — speech recognition will still try to understand your reply.';
        }
        window.speechSynthesis.speak(utter);
      }catch(e){
        resolve();
      }
    });
  }

  function afterWordCue(word){
    wordProgressFill.style.width = '0%';
    if(!speechSupported){
      // No automatic scoring possible in this browser — record it as
      // unscored rather than asking the person to self-report.
      wordStatus.textContent = 'Speech recognition isn\'t supported in this browser, so this word can\'t be auto-scored — moving on.';
      recordWord('(speech recognition not supported)', false);
      return;
    }
    wordStatus.textContent = 'Now say the word you just heard…';
    // A short pause before listening avoids the mic picking up the tail end
    // of the spoken word itself (especially over speakers rather than headphones).
    setTimeout(() => listenForWord(word), 250);
  }

  function listenForWord(word){
    function start(){
      try{
        const rec = newRecognition();
        wordRecognition = rec;
        rec._handled = false; // flag lives on the rec itself (not a closure var) so
                               // recordWord() can suppress it from outside — e.g. when
                               // the skip button ends this word early via abort().

        rec.onresult = (event) => {
          if(rec._handled) return;
          rec._handled = true;
          const transcript = event.results[0][0].transcript.trim().toLowerCase();
          const target = word.toLowerCase();
          const correct = transcript === target || transcript.indexOf(target) !== -1;
          recordWord(transcript, correct);
        };
        rec.onerror = (event) => {
          if(rec._handled) return;
          rec._handled = true;
          // A single recognition attempt failing — including a 'not-allowed'
          // error from THIS attempt — does not necessarily mean the mic
          // permission itself was revoked. Browsers can surface 'not-allowed'
          // for transient reasons (recognition-service hiccups, especially
          // when switching to a less common recognition language like
          // Spanish or Mandarin). We already confirmed real permission once,
          // up front, via requestMicPermissionOnce(); we don't let one bad
          // attempt here cancel every remaining word in the test — each word
          // still gets its own fair, fresh attempt.
          if(event && event.error === 'not-allowed' && micPermissionState !== 'granted'){
            // Only treat as a genuine denial if we never actually got the
            // up-front grant in the first place.
            micPermissionState = 'denied';
            wordStatus.textContent = 'Microphone access was denied — this word is recorded as not heard.';
          } else {
            wordStatus.textContent = 'Didn\'t catch that (' + (event && event.error ? event.error : 'mic issue') + ') — this word is recorded as not heard, continuing to the next word.';
          }
          recordWord('(mic error: ' + (event && event.error ? event.error : 'unknown') + ')', false);
        };
        rec.onend = () => {
          if(!rec._handled){
            rec._handled = true;
            recordWord('(no speech detected)', false);
          }
        };
        rec.start();
      }catch(e){
        wordStatus.textContent = 'Speech recognition failed to start — this word is recorded as not heard, continuing to the next word.';
        recordWord('(recognition failed)', false);
      }
    }

    if(micPermissionState === 'granted'){
      // Tiny delay before each attempt — starting a brand-new recognition
      // instance immediately back-to-back (especially right after switching
      // languages) is more prone to spurious startup errors in some browsers.
      setTimeout(start, 150);
    } else if(micPermissionState === 'denied'){
      wordStatus.textContent = 'Microphone access was denied — this word is recorded as not heard.';
      recordWord('(mic denied)', false);
    } else {
      // Permission still resolving (e.g. very first word) — wait for the
      // single up-front prompt to settle, then proceed without asking again.
      requestMicPermissionOnce().then(granted => {
        if(granted) setTimeout(start, 150);
        else {
          wordStatus.textContent = 'Microphone access was denied — this word is recorded as not heard.';
          recordWord('(mic denied)', false);
        }
      });
    }
  }

  function recordWord(heard, correct){
    if(wordRecognition){
      // Mark it handled BEFORE aborting: abort() fires this instance's own
      // onerror/onend asynchronously, and without this flag that would call
      // recordWord() a second time for the same word (e.g. pressing skip
      // mid-listen used to record two entries and desync every word after it).
      wordRecognition._handled = true;
      try{ wordRecognition.abort(); }catch(e){}
    }
    wordRecords.push({ word: WORD_LIST[wordIndex], heard: heard, correct: correct, level: currentLevel().label });
    wordIndex++;
    setTimeout(runWordStep, 350);
  }

  function finishWordTest(){
    wordRunning.style.display = 'none';
    wordResultsWrap.style.display = 'block';
    releaseMicStream();
    const correctCount = wordRecords.filter(r => r.correct).length;
    const pct = Math.round((correctCount / WORD_LIST.length) * 100);
    wordAccuracySummary.textContent = 'Accuracy: ' + correctCount + ' of ' + WORD_LIST.length + ' words (' + pct + '%)';
    wordTableBody.innerHTML = wordRecords.map(r =>
      '<tr><td>' + r.word + '</td><td>' + r.level + '</td><td>' + r.heard + '</td><td class="' + (r.correct ? 'result-correct' : 'result-wrong') + '">' + (r.correct ? 'Correct' : 'Incorrect') + '</td></tr>'
    ).join('');
    // Now that both the tone test and the word test are complete, reveal
    // the full results together.
    revealCombinedResults();
  }
