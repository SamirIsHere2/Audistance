  // ---------------- distance / monitor wiring ----------------
  const video = document.getElementById('video');
  const overlay = document.getElementById('overlay');
  const stageMsg = document.getElementById('stageMsg');
  const startBtn = document.getElementById('startBtn');
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const readoutText = document.getElementById('readoutText');

  const dotDistance = document.getElementById('dot-distance');
  const valDistance = document.getElementById('val-distance');
  const hintDistance = document.getElementById('hint-distance');
  const dotH = document.getElementById('dot-h');
  const valH = document.getElementById('val-h');
  const hintH = document.getElementById('hint-h');
  const dotV = document.getElementById('dot-v');
  const valV = document.getElementById('val-v');
  const hintV = document.getElementById('hint-v');
  const dotLight = document.getElementById('dot-light');
  const valLight = document.getElementById('val-light');
  const hintLight = document.getElementById('hint-light');

  const minInput = document.getElementById('minRange');
  const maxInput = document.getElementById('maxRange');
  const unitLabel = document.getElementById('unitLabel');
  const cmBtn = document.getElementById('cmBtn');
  const ftBtn = document.getElementById('ftBtn');

  const advToggle = document.getElementById('advToggle');
  const advRow = document.getElementById('advRow');
  const sensSlider = document.getElementById('sensSlider');
  const sensVal = document.getElementById('sensVal');

  advToggle.addEventListener('click', () => advRow.classList.toggle('show'));
  sensSlider.addEventListener('input', () => { sensVal.textContent = parseFloat(sensSlider.value).toFixed(2); });

  // --- in-page, distance-based volume (test tone) ---
  const volToggle = document.getElementById('volToggle');
  const volToggleLabel = document.getElementById('volToggleLabel');
  const testToneRow = document.getElementById('testToneRow');
  const toneBtn = document.getElementById('toneBtn');
  const volReadout = document.getElementById('volReadout');
  const volModal = document.getElementById('volModal');
  const volAllow = document.getElementById('volAllow');
  const volDeny = document.getElementById('volDeny');

  let volumeFeatureAllowed = false;
  let volumeFeatureOn = false;
  let audioCtx = null, gainNode = null, oscNode = null, toneAudioPlaying = false;

  volToggle.addEventListener('change', () => {
    if(volToggle.checked && !volumeFeatureAllowed){
      volToggle.checked = false;
      volModal.classList.add('show');
      return;
    }
    volumeFeatureOn = volToggle.checked;
    volToggleLabel.textContent = volumeFeatureOn ? 'On' : 'Off';
    testToneRow.style.display = volumeFeatureOn ? 'flex' : 'none';
    if(!volumeFeatureOn) stopTone();
  });

  volAllow.addEventListener('click', () => {
    volumeFeatureAllowed = true;
    volModal.classList.remove('show');
    volToggle.checked = true;
    volumeFeatureOn = true;
    volToggleLabel.textContent = 'On';
    testToneRow.style.display = 'flex';
  });
  volDeny.addEventListener('click', () => {
    volModal.classList.remove('show');
    volToggle.checked = false;
  });

  function ensureAudio(){
    if(!audioCtx){
      audioCtx = ensureSharedAudio();
      gainNode = audioCtx.createGain();
      gainNode.gain.value = 0.5;
      gainNode.connect(audioCtx.destination);
    }
  }

  function startTone(){
    ensureAudio();
    if(oscNode) return;
    oscNode = audioCtx.createOscillator();
    oscNode.type = 'sine';
    oscNode.frequency.value = 330;
    oscNode.connect(gainNode);
    oscNode.start();
    toneAudioPlaying = true;
    toneBtn.textContent = 'Stop test tone';
  }
  function stopTone(){
    if(oscNode){
      try{ oscNode.stop(); } catch(e){}
      oscNode.disconnect();
      oscNode = null;
    }
    toneAudioPlaying = false;
    toneBtn.textContent = 'Play test tone';
  }
  toneBtn.addEventListener('click', () => {
    if(toneAudioPlaying) stopTone(); else startTone();
  });

  // Optimal listening zone: 2-4 ft, targeting ~65-75 dB SPL.
  // A web page can't measure or guarantee true room SPL — actual loudness
  // depends on the device's own volume/speakers, which JS has no visibility
  // into. REFERENCE_DB is an assumed SPL at unity gain (1.0) on a typical
  // laptop/phone at a comfortable system volume, used only to translate the
  // 65-75 dB target into a WebAudio gain value. Treat the dB readout as an
  // estimate/guide, not a calibrated measurement.
  const VOL_NEAR_CM = 61;   // 2 ft
  const VOL_FAR_CM = 122;   // 4 ft
  const VOL_FLOOR_DB = 65;  // target dB at the near edge (2 ft)
  const VOL_CEIL_DB = 75;   // target dB at the far edge (4 ft)
  const REFERENCE_DB = 85;  // assumed SPL at gain = 1.0 (unity)
  function dbForDistance(distanceCm){
    const t = (distanceCm - VOL_NEAR_CM) / (VOL_FAR_CM - VOL_NEAR_CM);
    const clampedT = Math.max(0, Math.min(1, t));
    return VOL_FLOOR_DB + clampedT * (VOL_CEIL_DB - VOL_FLOOR_DB);
  }
  function volumeForDistance(distanceCm){
    const db = dbForDistance(distanceCm);
    return Math.pow(10, (db - REFERENCE_DB) / 20);
  }

  const RED = '#D8493D', AMBER = '#C98A24', GREEN = '#3AA179';

  const AVG_FACE_WIDTH_CM = 14;
  const ASSUMED_FOCAL_PX = 600;

  let unit = 'ft';
  cmBtn.addEventListener('click', () => setUnit('cm'));
  ftBtn.addEventListener('click', () => setUnit('ft'));
  function setUnit(u){
    unit = u;
    cmBtn.classList.toggle('active', u==='cm');
    ftBtn.classList.toggle('active', u==='ft');
    unitLabel.textContent = u;
    if(u === 'ft'){
      minInput.value = Math.round((minInput.value / 30.48) * 10) / 10;
      maxInput.value = Math.round((maxInput.value / 30.48) * 10) / 10;
    } else {
      minInput.value = Math.round(minInput.value * 30.48);
      maxInput.value = Math.round(maxInput.value * 30.48);
    }
    updateRecommendedText();
  }

  // ---- "Choose your shape" overlay picker ----
  // The selected shape controls what drawLoop() (in face-detection.js) draws
  // around the detected face — read from here via window.overlayShape.
  window.overlayShape = 'circle';
  const shapePicker = document.getElementById('shapePicker');
  if(shapePicker){
    shapePicker.querySelectorAll('.shape-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        shapePicker.querySelectorAll('.shape-btn').forEach(b => b.classList.toggle('active', b === btn));
        window.overlayShape = btn.getAttribute('data-shape');
      });
    });
  }

  // ---- "Recommended" box text (mirrors the min/max range inputs) ----
  const recRangeText = document.getElementById('recRangeText');
  const recDbText = document.getElementById('recDbText');
  function updateRecommendedText(){
    if(!recRangeText) return;
    const min = minInput.value, max = maxInput.value;
    recRangeText.textContent = min + ' – ' + max + ' ' + unit;
    if(recDbText) recDbText.textContent = VOL_FLOOR_DB + ' – ' + VOL_CEIL_DB + ' dB';
  }
  minInput.addEventListener('input', updateRecommendedText);
  maxInput.addEventListener('input', updateRecommendedText);
  updateRecommendedText();

  function rangeCm(){
    let min = parseFloat(minInput.value) || 0;
    let max = parseFloat(maxInput.value) || 0;
    if(unit === 'ft'){ min *= 30.48; max *= 30.48; }
    return [Math.min(min,max), Math.max(min,max)];
  }

