  // ---------------- App Connections page – Spotify ----------------
  // The connections page has its own Connect/Disconnect buttons that share
  // the same underlying Spotify state as the Distance page.
  // We wire them up after the main Spotify variables are declared below,
  // so we use a small helper that runs once the whole IIFE has set up.
  function wireConnectionsPageSpotify(){
    const connBtn        = document.getElementById('connSpotifyBtn');
    const connDisconnect = document.getElementById('connSpotifyDisconnectBtn');
    const connPre        = document.getElementById('connSpotifyPreConnect');
    const connPost       = document.getElementById('connSpotifyPostConnect');
    const connStatus     = document.getElementById('connSpotifyStatus');
    const connVolToggle  = document.getElementById('connSpotifyVolToggle');
    const connVolLabel   = document.getElementById('connSpotifyVolLabel');

    if(!connBtn) return;

    // Mirror whatever state the Distance-page Spotify is already in
    function syncConnPanel(){
      if(typeof spotifyAccessToken !== 'undefined' && spotifyAccessToken){
        connPre.style.display  = 'none';
        connPost.style.display = 'block';
      } else {
        connPre.style.display  = 'block';
        connPost.style.display = 'none';
      }
    }
    syncConnPanel();

    // Connect button – kicks off the same PKCE flow
    connBtn.addEventListener('click', async () => {
      const verifier = randomString(64);
      sessionStorage.setItem('otoo_sp_verifier', verifier);
      sessionStorage.setItem('otoo_sp_client_id', SPOTIFY_CLIENT_ID);
      const challenge = base64url(await sha256(verifier));
      const params = new URLSearchParams({
        response_type:'code', client_id:SPOTIFY_CLIENT_ID,
        scope:SPOTIFY_SCOPES, code_challenge_method:'S256',
        code_challenge:challenge, redirect_uri:SPOTIFY_REDIRECT_URI
      });
      window.location.href = 'https://accounts.spotify.com/authorize?' + params.toString();
    });

    // Disconnect
    connDisconnect.addEventListener('click', () => {
      document.getElementById('spotifyDisconnectBtn').click();
      syncConnPanel();
      connStatus.textContent = 'Disconnected.';
      connStatus.className = 'sp-status';
    });

    // Volume toggle mirrors the Distance page toggle
    connVolToggle.addEventListener('change', () => {
      const distToggle = document.getElementById('spotifyVolToggle');
      if(distToggle) distToggle.checked = connVolToggle.checked;
      if(connVolToggle.checked){
        document.getElementById('spotifyVolAllow') && document.getElementById('spotifyVolAllow').click();
      }
      connVolLabel.textContent = connVolToggle.checked ? 'Volume link on' : 'Volume link off';
    });
  }

