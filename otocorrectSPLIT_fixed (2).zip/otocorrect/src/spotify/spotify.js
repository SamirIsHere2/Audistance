  // ---------------- Spotify (PKCE, no client secret) ----------------
  const spotifyConnectBtn = document.getElementById('spotifyConnectBtn');
  const spotifyDisconnectBtn = document.getElementById('spotifyDisconnectBtn');
  const spotifyPreConnect = document.getElementById('spotifyPreConnect');
  const spotifyPostConnect = document.getElementById('spotifyPostConnect');
  const spotifyStatus = document.getElementById('spotifyStatus');
  const spotifyVolToggle = document.getElementById('spotifyVolToggle');
  const spotifyVolToggleLabel = document.getElementById('spotifyVolToggleLabel');
  const spotifyVolReadout = document.getElementById('spotifyVolReadout');
  const spotifyVolModal = document.getElementById('spotifyVolModal');
  const spotifyVolAllow = document.getElementById('spotifyVolAllow');
  const spotifyVolDeny = document.getElementById('spotifyVolDeny');

  const SPOTIFY_CLIENT_ID = 'f520bc03e6e64954a05385ef23bbb946';
  const SPOTIFY_REDIRECT_URI = 'https://www.otocorrect.com/';
  const SPOTIFY_SCOPES = 'user-read-playback-state user-modify-playback-state';

  let spotifyAccessToken = null;
  let spotifyRefreshToken = null;
  let spotifyTokenExpiry = 0;
  let spotifyFeatureAllowed = false;
  let spotifyFeatureOn = false;
  let spotifyLastSentVolume = null;
  let spotifyLastSentAt = 0;
  let spotifyRateLimitedUntil = 0;

  function setSpotifyStatus(msg, kind){
    spotifyStatus.textContent = msg || '';
    spotifyStatus.className = 'sp-status' + (kind ? ' ' + kind : '');
  }

  function randomString(len){
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let out = '';
    const arr = new Uint8Array(len);
    crypto.getRandomValues(arr);
    for(let i=0;i<len;i++) out += chars[arr[i] % chars.length];
    return out;
  }
  function base64url(buffer){
    let str = '';
    const bytes = new Uint8Array(buffer);
    for(let i=0;i<bytes.length;i++) str += String.fromCharCode(bytes[i]);
    return btoa(str).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  }
  async function sha256(plain){
    const data = new TextEncoder().encode(plain);
    return await crypto.subtle.digest('SHA-256', data);
  }

  spotifyConnectBtn.addEventListener('click', async () => {
    const clientId = SPOTIFY_CLIENT_ID;
    const verifier = randomString(64);
    sessionStorage.setItem('otoo_sp_verifier', verifier);
    sessionStorage.setItem('otoo_sp_client_id', clientId);
    const challenge = base64url(await sha256(verifier));
    const params = new URLSearchParams({
      response_type: 'code',
      client_id: clientId,
      scope: SPOTIFY_SCOPES,
      code_challenge_method: 'S256',
      code_challenge: challenge,
      redirect_uri: SPOTIFY_REDIRECT_URI
    });
    window.location.href = 'https://accounts.spotify.com/authorize?' + params.toString();
  });

  spotifyDisconnectBtn.addEventListener('click', () => {
    spotifyAccessToken = null;
    spotifyRefreshToken = null;
    spotifyTokenExpiry = 0;
    spotifyFeatureOn = false;
    spotifyFeatureAllowed = false;
    spotifyVolToggle.checked = false;
    spotifyVolToggleLabel.textContent = 'Off';
    sessionStorage.removeItem('otoo_sp_verifier');
    sessionStorage.removeItem('otoo_sp_client_id');
    spotifyPostConnect.style.display = 'none';
    spotifyPreConnect.style.display = 'block';
    setSpotifyStatus('Disconnected.', '');
  });

  spotifyVolToggle.addEventListener('change', () => {
    if(spotifyVolToggle.checked && !spotifyFeatureAllowed){
      spotifyVolToggle.checked = false;
      spotifyVolModal.classList.add('show');
      return;
    }
    spotifyFeatureOn = spotifyVolToggle.checked;
    spotifyVolToggleLabel.textContent = spotifyFeatureOn ? 'On' : 'Off';
  });
  spotifyVolAllow.addEventListener('click', () => {
    spotifyFeatureAllowed = true;
    spotifyVolModal.classList.remove('show');
    spotifyVolToggle.checked = true;
    spotifyFeatureOn = true;
    spotifyVolToggleLabel.textContent = 'On';
  });
  spotifyVolDeny.addEventListener('click', () => {
    spotifyVolModal.classList.remove('show');
    spotifyVolToggle.checked = false;
  });

  async function exchangeSpotifyCode(code){
    const clientId = sessionStorage.getItem('otoo_sp_client_id');
    const verifier = sessionStorage.getItem('otoo_sp_verifier');
    if(!clientId || !verifier){
      setSpotifyStatus('Lost the connection state after redirect — click Connect Spotify again.', 'err');
      return;
    }
    try{
      const resp = await fetch('https://accounts.spotify.com/api/token', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
          client_id: clientId,
          grant_type: 'authorization_code',
          code: code,
          redirect_uri: SPOTIFY_REDIRECT_URI,
          code_verifier: verifier
        })
      });
      const data = await resp.json();
      if(!resp.ok){
        setSpotifyStatus('Spotify connection failed: ' + (data.error_description || data.error || resp.status), 'err');
        return;
      }
      spotifyAccessToken = data.access_token;
      spotifyRefreshToken = data.refresh_token;
      spotifyTokenExpiry = Date.now() + (data.expires_in * 1000);
      spotifyPreConnect.style.display = 'none';
      spotifyPostConnect.style.display = 'block';
      setSpotifyStatus('Connected. Turn on the toggle below to link volume to distance.', 'ok');
    } catch(e){
      setSpotifyStatus('Spotify connection failed: ' + e.message, 'err');
    }
  }

  async function refreshSpotifyToken(){
    const clientId = sessionStorage.getItem('otoo_sp_client_id');
    if(!spotifyRefreshToken || !clientId) return false;
    try{
      const resp = await fetch('https://accounts.spotify.com/api/token', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
          client_id: clientId,
          grant_type: 'refresh_token',
          refresh_token: spotifyRefreshToken
        })
      });
      const data = await resp.json();
      if(!resp.ok) return false;
      spotifyAccessToken = data.access_token;
      if(data.refresh_token) spotifyRefreshToken = data.refresh_token;
      spotifyTokenExpiry = Date.now() + (data.expires_in * 1000);
      return true;
    } catch(e){ return false; }
  }

  async function setSpotifyVolume(percent){
    if(!spotifyAccessToken) return;
    const now = Date.now();
    if(now < spotifyRateLimitedUntil) return;
    if(spotifyLastSentVolume !== null && Math.abs(percent - spotifyLastSentVolume) < 3) return;
    if(now - spotifyLastSentAt < 700) return;
    if(now > spotifyTokenExpiry - 5000){
      const ok = await refreshSpotifyToken();
      if(!ok){ setSpotifyStatus('Spotify session expired — reconnect.', 'err'); return; }
    }
    spotifyLastSentAt = now;
    spotifyLastSentVolume = percent;
    try{
      const resp = await fetch('https://api.spotify.com/v1/me/player/volume?volume_percent=' + percent, {
        method: 'PUT',
        headers: {'Authorization': 'Bearer ' + spotifyAccessToken}
      });
      if(resp.status === 204){
        setSpotifyStatus('Linked to distance.', 'ok');
      } else if(resp.status === 404){
        setSpotifyStatus('No active Spotify device — start playing something in Spotify first.', 'err');
      } else if(resp.status === 403){
        setSpotifyStatus('Spotify Premium is required for volume control.', 'err');
      } else if(resp.status === 429){
        const retryAfter = parseInt(resp.headers.get('Retry-After') || '5', 10);
        spotifyRateLimitedUntil = Date.now() + retryAfter * 1000;
        setSpotifyStatus('Spotify rate limit hit, backing off briefly.', 'err');
      } else {
        setSpotifyStatus('Spotify volume update failed (' + resp.status + ').', 'err');
      }
    } catch(e){
      setSpotifyStatus('Spotify volume update failed: ' + e.message, 'err');
    }
  }

  (function checkSpotifyRedirect(){
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const err = params.get('error');
    if(code){
      showView('distance');
      exchangeSpotifyCode(code);
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if(err){
      showView('distance');
      setSpotifyStatus('Spotify authorization was cancelled or denied.', 'err');
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  })();

  // Wire up the App Connections page Spotify buttons now that all
  // Spotify state variables and helpers are defined.
  wireConnectionsPageSpotify();

