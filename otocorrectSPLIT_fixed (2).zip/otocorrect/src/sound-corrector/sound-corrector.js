  function soundCtx(){
    if(!soundAudioCtx){
      soundAudioCtx = ensureSharedAudio();
      eqInputGain = soundAudioCtx.createGain();
      eqInputGain.gain.value = 0.5;
      let prevNode = eqInputGain;
      EQ_BANDS.forEach(b => {
        const filt = soundAudioCtx.createBiquadFilter();
        filt.type = 'peaking';
        filt.frequency.value = b.freq;
        filt.Q.value = 1.1;
        filt.gain.value = 0;
        prevNode.connect(filt);
        prevNode = filt;
        eqFilters.push(filt);
      });
      prevNode.connect(soundAudioCtx.destination);
    }
    return soundAudioCtx;
  }

  function stopSoundSource(){
    if(currentSourceNode){
      try{ currentSourceNode.stop(); } catch(e){}
      try{ currentSourceNode.disconnect(); } catch(e){}
      currentSourceNode = null;
    }
    soundPlaying = false;
    eqPlayBtn.textContent = 'Play';
  }

  function makeNoiseBuffer(ctx){
    const bufferSize = 2 * ctx.sampleRate;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for(let i=0;i<bufferSize;i++) data[i] = Math.random()*2-1;
    return buffer;
  }

  function startSoundSource(){
    const ctx = soundCtx();
    stopSoundSource();
    if(currentSourceType === 'noise'){
      const src = ctx.createBufferSource();
      src.buffer = makeNoiseBuffer(ctx);
      src.loop = true;
      src.connect(eqInputGain);
      src.start();
      currentSourceNode = src;
    } else if(currentSourceType === 'tone'){
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(200, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(4000, ctx.currentTime + 6);
      osc.frequency.linearRampToValueAtTime(200, ctx.currentTime + 12);
      osc.connect(eqInputGain);
      osc.start();
      currentSourceNode = osc;
    } else if(currentSourceType === 'chord'){
      const merger = ctx.createGain();
      merger.gain.value = 1;
      merger.connect(eqInputGain);
      const freqs = [196, 246.94, 293.66, 392];
      const oscs = freqs.map(f => {
        const o = ctx.createOscillator();
        o.type = 'triangle';
        o.frequency.value = f;
        const g = ctx.createGain();
        g.gain.value = 0.22;
        o.connect(g);
        g.connect(merger);
        o.start();
        return o;
      });
      currentSourceNode = {
        stop: () => oscs.forEach(o => { try{ o.stop(); }catch(e){} }),
        disconnect: () => { merger.disconnect(); oscs.forEach(o=>{try{o.disconnect();}catch(e){}}); }
      };
    }
    soundPlaying = true;
    eqPlayBtn.textContent = 'Stop';
  }

  const eqPlayBtn = document.getElementById('eqPlayBtn');
  const sourceLabel = document.getElementById('sourceLabel');
  eqPlayBtn.addEventListener('click', () => {
    if(soundPlaying) stopSoundSource(); else startSoundSource();
  });
  document.getElementById('sourceNoise').addEventListener('click', () => setSource('noise', 'pink noise'));
  document.getElementById('sourceTone').addEventListener('click', () => setSource('tone', 'tone sweep'));
  document.getElementById('sourceChord').addEventListener('click', () => setSource('chord', 'music-like chord'));
  function setSource(type, label){
    currentSourceType = type;
    sourceLabel.textContent = 'Source: ' + label;
    if(soundPlaying) startSoundSource();
  }

  // ================= SOUND PAGE: CONNECT SPOTIFY =================
  // Shares the same underlying Spotify state as the Distance and App
  // Connections pages (spotify.js loads before this file). Mirrors the
  // wireConnectionsPageSpotify() pattern in connections/connections.js.
  (function wireSoundPageSpotify(){
    const soundBtn        = document.getElementById('soundSpotifyBtn');
    const soundDisconnect = document.getElementById('soundSpotifyDisconnectBtn');
    const soundPre        = document.getElementById('soundSpotifyPreConnect');
    const soundPost       = document.getElementById('soundSpotifyPostConnect');
    const soundStatus     = document.getElementById('soundSpotifyStatus');

    if(!soundBtn) return;

    function syncSoundPanel(){
      if(typeof spotifyAccessToken !== 'undefined' && spotifyAccessToken){
        soundPre.style.display  = 'none';
        soundPost.style.display = 'block';
      } else {
        soundPre.style.display  = 'block';
        soundPost.style.display = 'none';
      }
    }
    syncSoundPanel();

    soundBtn.addEventListener('click', async () => {
      const verifier = randomString(64);
      sessionStorage.setItem('otoo_sp_verifier', verifier);
      sessionStorage.setItem('otoo_sp_client_id', SPOTIFY_CLIENT_ID);
      const challenge = base64url(await sha256(verifier));
      const params = new URLSearchParams({
        response_type:'code', client_id:SPOTIFY_CLIENT_ID,
        scope:SPOTIFY_SCOPES, code_challenge_method:'S256',
        code_challenge:challenge, redirect_uri:SPOTIFY_REDIRECT_URI
      });
      window.location.href = 'https://accounts.spotify.com/authorize?' + params.toString();
    });

    soundDisconnect.addEventListener('click', () => {
      document.getElementById('spotifyDisconnectBtn').click();
      syncSoundPanel();
      soundStatus.textContent = 'Disconnected.';
      soundStatus.className = 'sp-status';
    });
  })();

  // ================= SOUND PAGE: FACE-CONTROLLED VOLUME =================
  const soundVideo = document.getElementById('soundVideo');
  const soundOverlay = document.getElementById('soundOverlay');
  const soundStageMsg = document.getElementById('soundStageMsg');
  const soundStartBtn = document.getElementById('soundStartBtn');
  const soundReadout = document.getElementById('soundReadout');
  const macBarFill = document.getElementById('macBarFill');
  const winBarFill = document.getElementById('winBarFill');
  const winVolLabel = document.getElementById('winVolLabel');

  let soundCtx2 = null;
  let soundLastFace = null;
  let soundMissCount = 0;
  let soundDetecting = false;

  soundStartBtn.addEventListener('click', startSoundCamera);

  function startSoundCamera(){
    soundReadout.textContent = 'Requesting camera…';
    navigator.mediaDevices.getUserMedia({ video: { width:640, height:480, facingMode:'user' }, audio:false })
      .then(stream => {
        soundVideo.srcObject = stream;
        soundStageMsg.style.display = 'none';
        return soundVideo.play();
      })
      .then(() => {
        soundOverlay.width = soundVideo.videoWidth || 640;
        soundOverlay.height = soundVideo.videoHeight || 480;
        soundCtx2 = soundOverlay.getContext('2d');
        soundReadout.textContent = 'Loading face detector…';
        return loadModels();
      })
      .then(() => {
        modelsReady = true;
        soundCtx(); // ensure the EQ audio graph (and eqInputGain) exists so volume can be linked right away
        soundReadout.textContent = 'Looking for a face…';
        requestAnimationFrame(soundDrawLoop);
        soundDetectTick();
      })
      .catch(err => {
        console.error(err);
        soundReadout.textContent = 'Camera access was blocked or the detector failed to load.';
      });
  }

  async function soundDetectTick(){
    if(!modelsReady) return;
    if(soundVideo.readyState >= 2 && !soundDetecting){
      soundDetecting = true;
      try{
        const opts = new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.3 });
        const result = await faceapi.detectSingleFace(soundVideo, opts);
        if(result && result.box && result.box.width > 20){
          soundLastFace = result.box;
          soundMissCount = 0;
        } else {
          soundMissCount++;
          if(soundMissCount > 6) soundLastFace = null;
        }
      } catch(e){ console.error('sound detection error', e); }
      soundDetecting = false;
    }
    setTimeout(soundDetectTick, 60);
  }

  function updateOsIcons(level){
    const pct = Math.round(level * 100);
    macBarFill.style.width = pct + '%';
    const fullWidth = 40;
    winBarFill.setAttribute('width', Math.max(0, (pct/100) * fullWidth));
    winVolLabel.textContent = 'WindowsOs · ' + pct + '%';
  }

  function soundDrawLoop(){
    requestAnimationFrame(soundDrawLoop);
    if(!soundCtx2) return;
    soundCtx2.clearRect(0,0,soundOverlay.width, soundOverlay.height);

    if(!soundLastFace){
      soundReadout.textContent = 'No face detected — face the camera directly, in decent light.';
      return;
    }

    const f = soundLastFace;
    const vw = soundOverlay.width;
    const distanceCm = (AVG_FACE_WIDTH_CM * ASSUMED_FOCAL_PX) / f.width;
    const level = volumeForDistance(distanceCm);

    if(eqInputGain && soundAudioCtx){
      eqInputGain.gain.setTargetAtTime(level, soundAudioCtx.currentTime, 0.03);
    }
    updateOsIcons(level);
    soundReadout.textContent = 'distance ~' + Math.round(distanceCm) + 'cm · volume ' + Math.round(level*100) + '%';

    soundCtx2.save();
    soundCtx2.strokeStyle = '#8B5CF6';
    soundCtx2.lineWidth = 2;
    soundCtx2.strokeRect(vw - f.x - f.width, f.y, f.width, f.height);
    soundCtx2.restore();
  }

