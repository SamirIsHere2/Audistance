  // ================= HEARING TEST / AUDIOGRAM =================
  const TEST_FREQS = [250, 500, 1000, 2000, 4000, 8000];
  const STEP_SECONDS = 10;

  const testIdle = document.getElementById('testIdle');
  const testRunning = document.getElementById('testRunning');
  const testResults = document.getElementById('testResults');
  const startTestBtn = document.getElementById('startTestBtn');
  const retakeTestBtn = document.getElementById('retakeTestBtn');
  const testFreqLabel = document.getElementById('testFreqLabel');
  const testSubLabel = document.getElementById('testSubLabel');
  const testProgressFill = document.getElementById('testProgressFill');
  const hearBtn = document.getElementById('hearBtn');
  const testStepCount = document.getElementById('testStepCount');
  const resultsSummary = document.getElementById('resultsSummary');
  const audiogramSvg = document.getElementById('audiogramSvg');

  let testCtx = null, testOsc = null, testGain = null;
  let testStepIndex = 0;
  let testResultsData = [];
  let testStepStart = 0;
  let testRAF = null;
  let testStepDone = false;

  startTestBtn.addEventListener('click', beginTest);
  retakeTestBtn.addEventListener('click', beginTest);
  hearBtn.addEventListener('click', onHeardClick);

  function beginTest(){
    testStepIndex = 0;
    testResultsData = [];
    testIdle.style.display = 'none';
    testResults.style.display = 'none';
    testRunning.style.display = 'block';
    testCtx = ensureSharedAudio();
    runStep();
  }

  function runStep(){
    if(testStepIndex >= TEST_FREQS.length){
      finishTest();
      return;
    }
    testStepDone = false;
    const freq = TEST_FREQS[testStepIndex];
    testFreqLabel.textContent = freq + ' Hz';
    testSubLabel.textContent = 'Listen closely — it starts quiet and gets louder…';
    testStepCount.textContent = 'Step ' + (testStepIndex+1) + ' of ' + TEST_FREQS.length;
    testProgressFill.style.width = '0%';

    stopTestTone();
    testOsc = testCtx.createOscillator();
    testGain = testCtx.createGain();
    testOsc.type = 'sine';
    testOsc.frequency.value = freq;
    testGain.gain.setValueAtTime(0.0001, testCtx.currentTime);
    testGain.gain.linearRampToValueAtTime(0.5, testCtx.currentTime + STEP_SECONDS);
    testOsc.connect(testGain);
    testGain.connect(testCtx.destination);
    testOsc.start();

    testStepStart = performance.now();
    tickStep();
  }

  function tickStep(){
    if(testStepDone) return;
    const elapsed = (performance.now() - testStepStart) / 1000;
    const pct = Math.min(100, (elapsed / STEP_SECONDS) * 100);
    testProgressFill.style.width = pct + '%';
    if(elapsed >= STEP_SECONDS){
      recordStep(1.0, false);
      return;
    }
    testRAF = requestAnimationFrame(tickStep);
  }

  function onHeardClick(){
    if(testStepDone) return;
    const elapsed = (performance.now() - testStepStart) / 1000;
    const frac = Math.max(0.02, Math.min(1, elapsed / STEP_SECONDS));
    recordStep(frac, true);
  }

  function recordStep(frac, heard){
    testStepDone = true;
    if(testRAF) cancelAnimationFrame(testRAF);
    stopTestTone();
    testResultsData.push({ freq: TEST_FREQS[testStepIndex], threshold: frac, heard: heard });
    testStepIndex++;
    setTimeout(runStep, 350);
  }

  function stopTestTone(){
    if(testOsc){
      try{ testOsc.stop(); }catch(e){}
      try{ testOsc.disconnect(); }catch(e){}
      testOsc = null;
    }
    if(testGain){
      try{ testGain.disconnect(); }catch(e){}
      testGain = null;
    }
  }

  function finishTest(){
    testRunning.style.display = 'none';
    testResults.style.display = 'block';
    const heardCount = testResultsData.filter(r => r.heard).length;
    resultsSummary.textContent = 'You detected ' + heardCount + ' of ' + TEST_FREQS.length + ' tones before the volume ramp finished. Lower bars below mean you noticed that frequency sooner (at a quieter level); taller bars mean it took longer, or it wasn\'t detected in time.';
    drawAudiogram(testResultsData);
  }

  function drawAudiogram(data){
    const W = 560, H = 300;
    const padL = 50, padR = 20, padT = 20, padB = 40;
    const chartW = W - padL - padR, chartH = H - padT - padB;
    const n = data.length;
    const xFor = i => padL + (chartW * (i + 0.5) / n);
    const yFor = frac => padT + frac * chartH;

    let svg = '';
    // gridlines
    for(let g=0; g<=4; g++){
      const y = padT + (chartH * g/4);
      svg += '<line x1="'+padL+'" y1="'+y+'" x2="'+(W-padR)+'" y2="'+y+'" stroke="#EDE1FB" stroke-width="1"/>';
    }
    // axis labels
    svg += '<text x="'+padL+'" y="'+(padT-6)+'" font-size="10" fill="#7C6C97" font-family="IBM Plex Mono, monospace">quick / soft</text>';
    svg += '<text x="'+padL+'" y="'+(H-padB+18)+'" font-size="10" fill="#7C6C97" font-family="IBM Plex Mono, monospace">slow / loud or missed</text>';

    // x labels + bars + line
    let points = [];
    data.forEach((d,i) => {
      const x = xFor(i);
      const y = yFor(d.threshold);
      points.push(x + ',' + y);
      const barColor = d.heard ? '#8B5CF6' : '#DED0F5';
      svg += '<rect x="'+(x-16)+'" y="'+y+'" width="32" height="'+(padT+chartH-y)+'" rx="4" fill="'+barColor+'" opacity="0.55"/>';
      svg += '<text x="'+x+'" y="'+(H-padB+30)+'" font-size="11" fill="#241B35" font-family="IBM Plex Mono, monospace" text-anchor="middle">'+(d.freq>=1000 ? (d.freq/1000)+'k' : d.freq)+'</text>';
      svg += '<circle cx="'+x+'" cy="'+y+'" r="5" fill="'+(d.heard ? '#6C3FC5' : '#B7A6D9')+'"/>';
    });
    svg += '<polyline points="'+points.join(' ')+'" fill="none" stroke="#8B5CF6" stroke-width="2"/>';

    audiogramSvg.innerHTML = svg;
  }
