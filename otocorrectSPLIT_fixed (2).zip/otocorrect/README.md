# OtoCorrect — organized source

Your original single `index.html` (~2,600 lines) is now split by feature,
following the folder shape you showed me. **No behavior was changed** — I
verified line-by-line that every bit of CSS, markup, and JS logic is
preserved exactly, just moved into smaller files.

```
src/
  index.html                    entry point — open this
  shared/
    styles.css                  all CSS (unchanged, one stylesheet)
    tabs.js                     top-nav tab switching
    audio-context.js            shared AudioContext helper
  auth/
    auth.js                     Firebase: Google popup + session sign-in/signup, ES module
    legacy-google-signin.js     older Google Identity Services sign-in widget
  lib/
    firebase.js                 Firebase app/auth/Firestore init — only file with your project config
  spotify/
    spotify.js                  Spotify PKCE connect/disconnect + volume control
  distance/
    distance.js                 camera-distance settings, test tone, unit toggle
    face-detection.js           face-api.js camera loop + distance/light readouts
  sound-corrector/
    sound-corrector.js          EQ bands, sound sources, live sound-corrector camera view
  hearing-test/
    hearing-test.js             one-minute hearing test + audiogram
  connections/
    connections.js              "App Connections" page wiring (calls into spotify.js)
```

## How to run it

Just like before — this needs no npm install, no build step:

```
cd src
python3 -m http.server 8000
```

Then open `http://localhost:8000`. **Don't double-click `index.html`** —
`auth/auth.js` is a real ES module (it `import`s from `lib/firebase.js`),
and browsers block ES module imports over `file://` for security reasons.
A tiny local server is all you need.

## Why plain JS, not real modules everywhere

Only `lib/firebase.js` and `auth/auth.js` use `import`/`export` — that
part was already written as an ES module in your original file. All the
other files (`distance.js`, `spotify.js`, etc.) are loaded as ordinary
`<script>` tags, in the same order they ran in originally, so they share
one global scope exactly like your original single `<script>` block did.
I kept it this way on purpose — real ES modules everywhere would mean
rewriting how these files talk to each other (shared variables like
`spotifyAccessToken`, `ensureSharedAudio()`), which risks introducing
bugs in code I can't fully test here (camera/mic/Spotify OAuth). This
version is byte-for-byte the same logic as before, just reorganized.

## Note on the Firebase config

Your Firebase `apiKey` is included in `lib/firebase.js` as it was in the
original — this is normal for Firebase web apps (it's not a secret; access
is controlled by your Firebase security rules, not by hiding this key).
