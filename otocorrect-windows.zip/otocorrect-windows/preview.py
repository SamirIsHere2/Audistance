"""
OtoCorrect for Windows -- live camera preview window.

Unlike the Mac build (which needed custom AppKit code because macOS's
Cocoa GUI has to run on the main thread and rumps already owns that
loop), Windows doesn't have that restriction -- OpenCV's own window
(cv2.imshow) works fine called from a background thread, which is much
simpler and needs no extra GUI library.
"""

import cv2


class CameraPreviewWindow:
    WINDOW_NAME = "OtoCorrect - Live"

    def __init__(self):
        self._visible = False
        self._created = False

    def show(self):
        self._visible = True

    def hide(self):
        self._visible = False
        if self._created:
            try:
                cv2.destroyWindow(self.WINDOW_NAME)
            except cv2.error:
                pass
            self._created = False

    def is_visible(self) -> bool:
        return self._visible

    def update_frame(self, bgr_frame) -> None:
        if not self._visible:
            return
        cv2.imshow(self.WINDOW_NAME, bgr_frame)
        self._created = True

    def pump_events(self) -> None:
        """Must be called regularly (from the same thread as
        update_frame) so the window actually repaints and responds to
        being closed. Also detects if the user closed it with the
        window's own X button, so the tray menu can stay in sync."""
        if not self._created:
            return
        cv2.waitKey(1)
        try:
            visible_prop = cv2.getWindowProperty(self.WINDOW_NAME, cv2.WND_PROP_VISIBLE)
        except cv2.error:
            visible_prop = 0
        if visible_prop < 1:
            self._visible = False
            self._created = False
