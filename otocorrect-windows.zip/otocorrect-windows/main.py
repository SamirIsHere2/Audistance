"""
OtoCorrect for Windows -- system tray app.

Lives in the system tray (bottom-right, near the clock, under the ^
arrow if hidden). Right-click (or left-click, depending on Windows
version) the icon to open the menu: Start Monitoring watches your
camera in the background and turns the whole system's volume up as you
move away from your PC and down as you lean in -- system-wide, not tied
to any one app.

HONEST SCOPE: this controls the ONE system-wide volume, not a specific
app's volume -- see volume.py for why that's a deliberate choice here
(matching the Mac app exactly), even though Windows can technically do
more.

FIRST RUN: Windows will use its camera privacy settings to allow/deny
access. If the camera doesn't seem to work, check Settings > Privacy &
Security > Camera, and make sure desktop apps are allowed to use it.
"""

import sys
import os
import threading
import time

import pystray
from PIL import Image

import distance
import volume
from preview import CameraPreviewWindow

# Matches the Chrome extension's / Mac app's tick rate (100ms) so all
# three feel equally responsive.
TICK_INTERVAL_SECONDS = 0.1


def resource_path(relative_path: str) -> str:
    """Works both when run as a plain script and when bundled into a
    single-file .exe by PyInstaller (which unpacks bundled data to a
    temp folder referenced by sys._MEIPASS at runtime)."""
    base_path = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)


class OtoCorrectApp:
    def __init__(self):
        self.tracker = distance.DistanceTracker()
        self.preview = CameraPreviewWindow()
        self.running = False
        self.original_volume = None
        self._status_text = "Distance and volume will show here once camera access is granted."
        self._worker_thread = None
        self._stop_event = threading.Event()

        image = Image.open(resource_path("app_icon.png"))
        self.icon = pystray.Icon("OtoCorrect", icon=image, title="OtoCorrect", menu=self._build_menu())

    # ---- tray menu -------------------------------------------------

    def _build_menu(self):
        return pystray.Menu(
            pystray.MenuItem(
                lambda item: "Stop Monitoring" if self.running else "Start Monitoring",
                self._on_toggle_monitoring,
            ),
            pystray.MenuItem(
                lambda item: "Hide Camera Preview" if self.preview.is_visible() else "Show Camera Preview",
                self._on_toggle_camera,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(lambda item: self._status_text, None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit", self._on_quit),
        )

    def _on_toggle_monitoring(self, icon, item):
        if self.running:
            self.stop_monitoring()
        else:
            self.start_monitoring()
        self.icon.update_menu()

    def _on_toggle_camera(self, icon, item):
        # "Show me the camera" implies "and make sure it's actually on."
        if not self.running:
            if not self.start_monitoring():
                self.icon.update_menu()
                return

        if self.preview.is_visible():
            self.preview.hide()
        else:
            self.preview.show()
        self.icon.update_menu()

    def _on_quit(self, icon, item):
        self.stop_monitoring()
        icon.stop()

    # ---- monitoring (camera + volume loop) -------------------------

    def start_monitoring(self) -> bool:
        if self.running:
            return True

        ok = self.tracker.start()
        if not ok:
            self.icon.notify(
                "Couldn't access the camera. Check Settings > Privacy & "
                "Security > Camera and make sure desktop apps are allowed.",
                "OtoCorrect",
            )
            return False

        try:
            self.original_volume = volume.get_system_volume()
        except Exception:
            self.original_volume = None

        self.running = True
        self._status_text = "Starting camera..."
        self._stop_event.clear()
        self._worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker_thread.start()
        return True

    def stop_monitoring(self):
        self.running = False
        self._stop_event.set()
        if self._worker_thread is not None:
            self._worker_thread.join(timeout=2)
        self._worker_thread = None

        self.tracker.stop()
        if self.preview.is_visible():
            self.preview.hide()

        # Restore whatever the volume was before we started, same
        # courtesy as the extension/Mac app.
        if self.original_volume is not None:
            try:
                volume.set_system_volume(self.original_volume)
            except Exception:
                pass

        self._status_text = "Not running."

    def _worker_loop(self):
        """Runs on a background thread. Owns the camera read, the
        preview window's imshow/waitKey calls (kept on one consistent
        thread), and the volume updates."""
        while not self._stop_event.is_set():
            readout = self.tracker.read()
            if readout is None:
                time.sleep(TICK_INTERVAL_SECONDS)
                continue

            if self.preview.is_visible():
                self.preview.update_frame(readout.frame)
                self.preview.pump_events()

            if not readout.face_found:
                self._status_text = "No one detected in frame."
            else:
                pct = round(readout.level * 100)
                try:
                    volume.set_system_volume(pct)
                    dist_text = f"{readout.distance_cm} cm" if readout.distance_cm else "..."
                    self._status_text = f"distance ~{dist_text} | volume {pct}%"
                except Exception:
                    self._status_text = "Couldn't set system volume."

            time.sleep(TICK_INTERVAL_SECONDS)

        self.preview.hide()

    def run(self):
        self.icon.run()


if __name__ == "__main__":
    OtoCorrectApp().run()
