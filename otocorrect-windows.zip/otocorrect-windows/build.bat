@echo off
setlocal

echo ============================================================
echo   OtoCorrect - one-time setup and build
echo   Just wait for this to finish. It will pause at the end
echo   so you can see where the finished app landed.
echo ============================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found on this computer.
    echo.
    echo Please install it first:
    echo   1. Go to https://www.python.org/downloads/windows/
    echo   2. Download the latest "Windows installer (64-bit)"
    echo   3. Run it, and on the FIRST screen check the box that says
    echo      "Add python.exe to PATH" before clicking Install
    echo   4. Come back and double-click this file again
    echo.
    pause
    exit /b 1
)

if not exist venv (
    echo Creating a private Python environment for OtoCorrect...
    python -m venv venv
    if errorlevel 1 (
        echo Something went wrong creating the environment. See the
        echo message above for details.
        pause
        exit /b 1
    )
)

call venv\Scripts\activate.bat

echo Installing dependencies -- this can take a few minutes the first
echo time, especially the camera library. Please be patient...
python -m pip install --upgrade pip setuptools wheel >nul

echo Making sure there's exactly one, clean copy of the camera library...
pip uninstall -y opencv-python opencv-python-headless opencv-contrib-python >nul 2>nul
pip install --no-cache-dir -r requirements.txt
if errorlevel 1 (
    echo.
    echo Dependency installation failed. See the error above.
    pause
    exit /b 1
)

echo.
echo Cleaning up any previous build...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist OtoCorrect.spec del /q OtoCorrect.spec

echo.
echo Building OtoCorrect (this mode packages a folder instead of a
echo single file -- that's intentional, it's the reliable option for
echo apps that use the camera library)...
pyinstaller --noconfirm --windowed --name OtoCorrect ^
    --icon app_icon.ico ^
    --add-data "app_icon.png;." ^
    --collect-all cv2 ^
    main.py

if errorlevel 1 (
    echo.
    echo The build failed. See the error above -- paste it back if
    echo you're not sure what it means.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   Done! Your app is in this folder:
echo   %cd%\dist\OtoCorrect
echo.
echo   IMPORTANT: move the WHOLE "OtoCorrect" folder (not just the
echo   .exe file inside it) anywhere you like -- Desktop, wherever.
echo   Then double-click OtoCorrect.exe inside that folder any time.
echo   No Python, no terminal, no venv needed from here on.
echo ============================================================
pause
