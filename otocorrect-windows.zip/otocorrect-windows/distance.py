"""
OtoCorrect for Windows -- camera distance estimation.

Uses OpenCV's built-in Haar Cascade frontal-face detector, which ships
inside the opencv-python package itself (no download, no internet access
needed at runtime) and is a real, trained detector.

DISTANCE MODEL: a heuristic -- a detected face's pixel width is inversely
proportional to real-world distance, calibrated with a rough
focal-length constant. Precise distance would need a calibrated/depth
camera; this is "close enough to feel responsive," not a measured
distance.

Distance-to-volume curve and update cadence are matched to the Chrome
extension build and the Mac app (see NEAR_CM/FAR_CM/SMOOTHING below and
main.py's tick interval), so all three feel the same.
"""

from __future__ import annotations

import cv2
from dataclasses import dataclass

ANALYSIS_W = 320
ANALYSIS_H = 240

# Distance -> volume curve. 60cm band, 40% floor instead of muting fully.
NEAR_CM = 40      # at or closer than this: minimum volume (40%)
FAR_CM = 100      # at or farther than this: maximum volume (100%)
MIN_LEVEL = 0.40
MAX_LEVEL = 1.0

# Rough calibration for a face-width-in-pixels -> distance-in-cm
# conversion at ANALYSIS_W=320. Adjust FOCAL_PX if distances read
# consistently too near/far on your webcam.
FOCAL_PX = 480
AVG_FACE_WIDTH_CM = 14

MAX_MISSES_BEFORE_LOST = 8
SMOOTHING = 0.35  # matches the extension's / Mac app's responsiveness


def volume_for_distance(distance_cm: float) -> float:
    t = (distance_cm - NEAR_CM) / (FAR_CM - NEAR_CM)
    clamped = max(0.0, min(1.0, t))
    return MIN_LEVEL + clamped * (MAX_LEVEL - MIN_LEVEL)


@dataclass
class Readout:
    face_found: bool
    distance_cm: float | None
    level: float           # smoothed 0.0-1.0
    frame: "object"        # BGR numpy array, mirrored + annotated, for the preview window


def _annotate(frame, face_box, distance_cm, level, face_found):
    """Draws a face box + a distance/volume readout directly onto the
    frame, then mirrors it horizontally so the live preview feels like
    looking in a mirror."""
    h, w = frame.shape[:2]

    if face_found and face_box is not None:
        x, y, fw, fh = face_box
        cv2.rectangle(frame, (x, y), (x + fw, y + fh), (219, 102, 192), 2)  # BGR, site's lavender accent
        pct = round(level * 100)
        dist_text = f"{distance_cm} cm" if distance_cm is not None else "..."
        label = f"{dist_text}  |  {pct}%"
    else:
        label = "No face detected"

    origin = (12, h - 16)
    cv2.putText(frame, label, origin, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 4, cv2.LINE_AA)
    cv2.putText(frame, label, origin, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1, cv2.LINE_AA)

    return cv2.flip(frame, 1)


class DistanceTracker:
    def __init__(self):
        cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        self._detector = cv2.CascadeClassifier(cascade_path)
        self._cap = None
        self._miss_count = 0
        self._smoothed_level = 1.0

    def start(self) -> bool:
        # CAP_DSHOW avoids a several-second startup delay some webcams
        # have with the default backend on Windows.
        self._cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        if not self._cap.isOpened():
            self._cap = cv2.VideoCapture(0)
        if not self._cap.isOpened():
            return False
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, ANALYSIS_W)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, ANALYSIS_H)
        self._miss_count = 0
        self._smoothed_level = 1.0
        return True

    def stop(self) -> None:
        if self._cap is not None:
            self._cap.release()
            self._cap = None

    def read(self) -> Readout | None:
        if self._cap is None:
            return None
        ok, frame = self._cap.read()
        if not ok or frame is None:
            return None

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self._detector.detectMultiScale(
            gray, scaleFactor=1.15, minNeighbors=5, minSize=(40, 40)
        )

        if len(faces) == 0:
            self._miss_count += 1
            lost = self._miss_count > MAX_MISSES_BEFORE_LOST
            annotated = _annotate(frame, None, None, self._smoothed_level, face_found=False)
            return Readout(face_found=not lost, distance_cm=None, level=self._smoothed_level, frame=annotated)

        faces = sorted(faces, key=lambda f: f[2] * f[3], reverse=True)
        face_box = faces[0]
        x, y, fw, fh = face_box

        self._miss_count = 0
        distance_cm = (AVG_FACE_WIDTH_CM * FOCAL_PX) / max(1, fw)
        target = volume_for_distance(distance_cm)
        self._smoothed_level += (target - self._smoothed_level) * SMOOTHING
        distance_cm = round(distance_cm)

        annotated = _annotate(frame, face_box, distance_cm, self._smoothed_level, face_found=True)
        return Readout(face_found=True, distance_cm=distance_cm, level=self._smoothed_level, frame=annotated)
