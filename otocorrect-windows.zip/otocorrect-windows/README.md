# OtoCorrect for Windows

A native Windows system tray app version of OtoCorrect's Sound feature:
it watches your camera, estimates roughly how far you are from your PC,
and turns the system volume up or down to match -- quieter close up,
louder as you move away. Works with whatever's actually making sound
(Spotify, Discord, a browser tab, a game), not just Chrome.

Behavior is intentionally identical to the Mac app: same 40%-100% volume
range, same 60cm distance band, same update speed, same live camera
preview with distance/volume burned into the picture.

## Why there's a build step at all

I can't hand you a ready-made `.exe` directly -- turning this Python
project into a real Windows executable (via PyInstaller) has to happen
*on* Windows itself; it can't be done on the machine that wrote this
code. `build.bat` below is that one required step, and it's designed so
you never have to open a terminal or type a single command to do it --
just double-click it once. Every launch after that is a completely
normal double-click on `OtoCorrect.exe`, forever, with no Python or
terminal involved.

## One-time setup

1. Unzip this folder anywhere (Desktop, Downloads, wherever).
2. Double-click **`build.bat`**.
3. A black window will pop up and do everything automatically:
   installing a private copy of Python's dependencies, then packaging
   everything into a single `.exe`. This takes a few minutes the first
   time (mostly downloading the camera library) -- just let it run.
   - If it says Python wasn't found, it'll tell you exactly where to
     download it and which box to check during install ("Add python.exe
     to PATH"). Install that, then double-click `build.bat` again.
4. When it's done, it'll tell you where the finished app is:
   `dist\OtoCorrect\` (a folder, with `OtoCorrect.exe` inside it)

## From here on: just double-click

Move the **whole `OtoCorrect` folder** (not just the `.exe` file by
itself) wherever you want -- Desktop, a Programs folder, wherever. Then
double-click `OtoCorrect.exe` inside that folder like any other app. No
Python, no terminal, no venv needed anymore. You can delete the rest of
this project folder (including `venv`, `build`, and the loose `dist`
wrapper) once you've moved the `OtoCorrect` folder out, if you want to
tidy up.

**Why a folder instead of a single file:** OpenCV (the camera library)
ships a lot of native Windows DLLs, and packaging everything into one
single `.exe` (PyInstaller's "onefile" mode) has known reliability
problems with those kinds of libraries -- it extracts everything fresh
to a temp folder on every launch, which can trip up native DLL loading.
The folder-based build avoids that problem entirely. It's one extra
click deep (open the folder, then click the .exe) but far more reliable.

**First launch note:** since this isn't signed with a paid code-signing
certificate, Windows SmartScreen may say *"Windows protected your PC"*
the very first time you run it. Click **More info**, then **Run
anyway**. You only need to do this once.

**Camera permission:** the first time you Start Monitoring, Windows may
ask about camera access, or you may need to check
**Settings > Privacy & Security > Camera** and make sure desktop apps
are allowed to use it.

## Using it

- Find the "oto" icon in your system tray (bottom-right, near the
  clock -- click the little `^` arrow there if it's hidden).
- **Start Monitoring** -- begins the camera-to-volume loop in the
  background.
- **Show Camera Preview** -- opens a window with your live camera feed,
  the detected face boxed in lavender, and the current distance/volume
  burned into the picture, updating continuously. Auto-starts
  monitoring first if it wasn't already running. Closing that window
  (the X button) doesn't stop monitoring -- they're independent.
- The status line in the tray menu shows the live distance/volume
  readout too.
- **Quit** stops monitoring, restores your original volume, and closes
  the app.

## Honest scope

This moves the **one system-wide volume slider** -- the same one your
keyboard's volume keys and the taskbar speaker icon move. Everything
playing on your PC gets quieter or louder together, matching the Mac
app exactly.

Worth knowing: Windows *does* actually expose a real per-application
volume API (unlike macOS, which has no public one) -- so a future
version of this Windows app specifically could turn down just Spotify
while a call stays put. That's not built here, on purpose, so this app
behaves identically to the Mac one.

## Tuning

In `distance.py`:
- `NEAR_CM` / `FAR_CM` -- the distance band mapped to volume (40cm-100cm).
- `MIN_LEVEL` / `MAX_LEVEL` -- the volume range (40%-100%).
- `SMOOTHING` -- 0-1, how quickly it reacts frame to frame.
- `FOCAL_PX` -- rough camera calibration constant; adjust if distances
  read consistently too near/far on your webcam, then rebuild.

If you change any `.py` file, just double-click `build.bat` again to
produce an updated `.exe` (it reuses the existing `venv`, so it's much
faster the second time; it also cleans out old build files first so
you always get a fresh build).

## Troubleshooting

**`AttributeError: module 'cv2' has no attribute 'CascadeClassifier'`:**
This is a real breaking change in **OpenCV 5.0** (released 2026) --
`CascadeClassifier` was moved out of the base `opencv-python` package
into `opencv_contrib`. `requirements.txt` now pins
`opencv-python<5` to avoid this entirely, since this app only needs
basic Haar cascade + camera capture, not the contrib modules. If you
already have a `venv` from before this fix, force a clean reinstall:
```
venv\Scripts\python.exe -m pip uninstall -y opencv-python opencv-python-headless opencv-contrib-python
venv\Scripts\python.exe -m pip install --no-cache-dir "opencv-python<5"
```
then re-run `build.bat`.

## Files

- `main.py` -- the tray app itself (pystray): start/stop, camera preview
  toggle, status readout, the background worker loop
- `distance.py` -- camera capture + face detection (OpenCV's built-in
  Haar Cascade detector), the distance-to-volume curve, frame annotation
- `preview.py` -- the live camera preview window (plain OpenCV window --
  simpler than the Mac build since Windows doesn't need a custom
  AppKit-style window)
- `volume.py` -- Windows system volume get/set via pycaw
- `build.bat` -- the one-time, double-click-only setup + build script
- `app_icon.png` / `app_icon.ico` -- the lavender OtoCorrect mark, used
  as the tray icon and the `.exe`'s icon
- `requirements.txt` -- Python dependencies
