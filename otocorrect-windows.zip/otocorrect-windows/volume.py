"""
OtoCorrect for Windows -- system volume control.

Uses pycaw, a thin wrapper around Windows' Core Audio APIs
(IAudioEndpointVolume), to get/set the master output volume -- the same
one the volume keys / taskbar speaker icon control.

TWO FIXES BAKED IN HERE, both found the hard way:

1. COM must be initialized on every thread that touches it. This module
   gets called from a background worker thread (see main.py), which
   Python never initializes COM on automatically -- only the main
   thread sometimes gets that implicitly. Skipping this can make calls
   fail outright on some setups.

2. pycaw changed its API in 2024+ releases: AudioUtilities.GetSpeakers()
   used to return a raw COM device that you had to manually .Activate()
   and cast to IAudioEndpointVolume. Newer pycaw wraps that device and
   exposes the volume control directly as a ready-made .EndpointVolume
   property instead. Calling the old manual .Activate() pattern on the
   new wrapper doesn't raise an error -- it just silently returns
   something that doesn't actually control anything, which is exactly
   the "no crash, numbers update, but nothing happens" bug this was
   hitting. This module checks for the new property first and only
   falls back to the manual/legacy pattern if it's not present.

NOTE ON SCOPE: Windows *does* actually expose a real per-application
volume API (IAudioSessionManager2 / IAudioSessionControl2) -- unlike
macOS, which has no public API for that. This build intentionally
sticks to the single system-wide volume for exact behavioral parity
with the Mac app ("identical" apps). Per-app volume (e.g. turning down
just Spotify while a call stays put) would be a genuine future upgrade
specific to Windows, not implemented here.
"""

from ctypes import cast, POINTER

import comtypes
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume


def _ensure_com_initialized() -> None:
    try:
        comtypes.CoInitialize()
    except OSError:
        pass  # already initialized on this thread -- fine, not an error


def _get_volume_interface():
    _ensure_com_initialized()
    devices = AudioUtilities.GetSpeakers()

    # Modern pycaw (2024+): the device wrapper already exposes the
    # volume-control interface directly.
    if hasattr(devices, "EndpointVolume"):
        return devices.EndpointVolume

    # Legacy pycaw: activate + cast the raw COM device manually.
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    return cast(interface, POINTER(IAudioEndpointVolume))


def get_system_volume() -> int:
    """Returns current system output volume as an int 0-100."""
    vol = _get_volume_interface()
    scalar = vol.GetMasterVolumeLevelScalar()  # 0.0-1.0
    return round(scalar * 100)


def set_system_volume(pct: int) -> None:
    """Sets system output volume. pct is clamped to 0-100."""
    pct = max(0, min(100, int(pct)))
    vol = _get_volume_interface()
    vol.SetMasterVolumeLevelScalar(pct / 100.0, None)


def is_muted() -> bool:
    vol = _get_volume_interface()
    return bool(vol.GetMute())
