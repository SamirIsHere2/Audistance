// Bridge for the hearing-test page's "don't see your language?" box —
// hearing-test.js is a plain (non-module) script, so it can't import
// Firestore itself. This tiny module wires window.submitLanguageRequest
// to the shared Firebase app instance.
import { submitLanguageRequest } from '../lib/firebase.js';

window.submitLanguageRequest = submitLanguageRequest;
