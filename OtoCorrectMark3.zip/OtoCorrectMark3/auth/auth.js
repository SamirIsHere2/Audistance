// Wires up the landing page, sign-in/create-account tabs, Google popup,
// and Firebase email/password forms. Loaded as a module so it can
// import the shared Firebase app instance from lib/firebase.js.
import {
  auth, googleProvider, ensureUserProfile,
  signInWithPopup, signOut, onAuthStateChanged,
  createUserWithEmailAndPassword, signInWithEmailAndPassword
} from '../lib/firebase.js';

  // ── Landing / sign-in screen wiring ────────────────────────────────────
  const authOverlay   = document.getElementById('authOverlay');
  const appContent    = document.getElementById('appContent');
  const landingHero   = document.querySelector('.landing-hero');
  const landingCards  = document.querySelector('.landing-cards');
  const landingNote   = document.querySelector('.landing-note');
  const landingTopbar = document.querySelector('.landing-topbar');
  const signinPage    = document.getElementById('signinPage');

  function showLandingPage(){
    signinPage.style.display    = 'none';
    landingTopbar.style.display = '';
    landingHero.style.display   = '';
    landingCards.style.display  = '';
    landingNote.style.display   = '';
  }
  function showSignInPage(){
    landingTopbar.style.display = 'none';
    landingHero.style.display   = 'none';
    landingCards.style.display  = 'none';
    landingNote.style.display   = 'none';
    signinPage.style.display    = 'flex';
    signinPage.style.flexDirection = 'column';
    signinPage.style.alignItems = 'center';
    signinPage.style.justifyContent = 'center';
  }

  // Navigate to sign-in page when either landing button is clicked.
  // "Sign in" opens the Sign in tab; "Get started" opens the Create account tab.
  document.getElementById('landingSignInBtn').addEventListener('click', () => {
    showSignInPage();
    showSignInTab();
  });
  document.getElementById('landingGetStartedBtn').addEventListener('click', () => {
    showSignInPage();
    showCreateTab();
  });

  // Back button returns to landing
  document.getElementById('signinBackBtn').addEventListener('click', showLandingPage);

  // ── Google sign-in (Firebase popup) ──────────────────────────────────────
  document.getElementById('siGoogleBtn').addEventListener('click', async () => {
    try{
      await signInWithPopup(auth, googleProvider);
      // onAuthStateChanged (below) handles showing the app on success
    }catch(err){
      showSiMsg(friendlyGoogleError(err), true);
    }
  });

  function friendlyGoogleError(err){
    const code = (err && err.code) || '';
    if(code.includes('popup-closed-by-user')) return 'Google sign-in was cancelled.';
    return 'Could not sign in with Google. Please try again.';
  }

  // ── Tab switcher (Sign in / Create account) ──────────────────────────────
  const authTabSignIn   = document.getElementById('authTabSignIn');
  const authTabCreate   = document.getElementById('authTabCreate');
  const authPanelSignIn = document.getElementById('authPanelSignIn');
  const authPanelCreate = document.getElementById('authPanelCreate');
  const authHeading     = document.getElementById('authHeading');
  const authSubtitle    = document.getElementById('authSubtitle');

  function showSignInTab(){
    authTabSignIn.classList.add('active');
    authTabCreate.classList.remove('active');
    authPanelSignIn.style.display = '';
    authPanelCreate.style.display = 'none';
    authHeading.textContent  = 'Sign in';
    authSubtitle.textContent = 'Your hearing tools are waiting.';
  }
  function showCreateTab(){
    authTabCreate.classList.add('active');
    authTabSignIn.classList.remove('active');
    authPanelCreate.style.display = '';
    authPanelSignIn.style.display = 'none';
    authHeading.textContent  = 'Create account';
    authSubtitle.textContent = 'Set up your hearing tools in seconds.';
  }
  authTabSignIn.addEventListener('click', showSignInTab);
  authTabCreate.addEventListener('click', showCreateTab);

  // ── Email / password sign-in form (real Firebase account) ───────────────
  const siForm      = document.getElementById('siForm');
  const siSubmitBtn = document.getElementById('siSubmitBtn');
  const siMsg       = document.getElementById('siMsg');

  function showAuthMsg(msgEl, text, isError){
    msgEl.textContent = text;
    msgEl.style.display = 'block';
    msgEl.style.background = isError ? '#FFF0EF' : '#EDFBF4';
    msgEl.style.color = isError ? 'var(--red)' : 'var(--green)';
    msgEl.style.border = isError ? '1px solid #F5C5C1' : '1px solid #B6EDD4';
  }
  function showSiMsg(text, isError){ showAuthMsg(siMsg, text, isError); }

  function friendlyEmailError(err){
    const code = (err && err.code) || '';
    if(code.includes('email-already-in-use')) return 'An account with that email already exists.';
    if(code.includes('invalid-email')) return 'Please enter a valid email address.';
    if(code.includes('weak-password')) return 'Password should be at least 6 characters.';
    if(code.includes('user-not-found') || code.includes('wrong-password') || code.includes('invalid-credential')){
      return 'Incorrect email or password.';
    }
    return 'Something went wrong. Please try again.';
  }

  siForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email    = document.getElementById('siEmail').value.trim().toLowerCase();
    const password = document.getElementById('siPassword').value;
    if(!email || !password){ showSiMsg('Please fill in both fields.', true); return; }

    siSubmitBtn.disabled = true;
    try{
      await signInWithEmailAndPassword(auth, email, password);
      // onAuthStateChanged (below) handles showing the app on success
    }catch(err){
      showSiMsg(friendlyEmailError(err), true);
    }finally{
      siSubmitBtn.disabled = false;
    }
  });

  // ── Email / password create-account form (real Firebase account) ────────
  const suForm      = document.getElementById('suForm');
  const suMsg       = document.getElementById('suMsg');

  suForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email    = document.getElementById('suEmail').value.trim().toLowerCase();
    const password = document.getElementById('suPassword').value;
    if(!email || !password){ showAuthMsg(suMsg, 'Please fill in both fields.', true); return; }
    if(password.length < 8){ showAuthMsg(suMsg, 'Password must be at least 8 characters.', true); return; }

    try{
      await createUserWithEmailAndPassword(auth, email, password);
      // onAuthStateChanged (below) handles showing the app and creating
      // the Firestore profile doc on success
    }catch(err){
      showAuthMsg(suMsg, friendlyEmailError(err), true);
    }
  });

  // ── Shared sign-in success ───────────────────────────────────────────────
  function signInSuccess(displayName, avatarUrl){
    // Hide landing, show app
    authOverlay.classList.add('hidden');
    appContent.classList.remove('hidden');
    // Populate topbar chip
    const chip   = document.getElementById('authChip');
    const siBtn  = document.getElementById('signInBtn');
    const avatar = document.getElementById('authAvatar');
    const name   = document.getElementById('authName');
    if(chip && siBtn){
      if(avatar) avatar.src = avatarUrl;
      if(name)   name.textContent = displayName;
      siBtn.style.display  = 'none';
      chip.style.display   = 'flex';
    }
  }

  // ── React to Firebase auth state (drives the Google popup flow) ─────────
  let firebaseUserActive = false;
  onAuthStateChanged(auth, (user) => {
    if(user){
      firebaseUserActive = true;
      ensureUserProfile(user).catch(() => {});
      signInSuccess(user.displayName || user.email || 'Signed in', user.photoURL || '');
    }
  });

  // ── Sign-out returns to landing ─────────────────────────────────────────
  function handleSignOut(){
    if(firebaseUserActive){ try{ signOut(auth); }catch(e){} firebaseUserActive = false; }
    appContent.classList.add('hidden');
    authOverlay.classList.remove('hidden');
    showLandingPage();
    const chip  = document.getElementById('authChip');
    const siBtn = document.getElementById('signInBtn');
    if(chip)  chip.style.display  = 'none';
    if(siBtn) siBtn.style.display = 'inline-block';
  }
  const oldSignOutBtn = document.getElementById('signOutBtn');
  const newSignOutBtn = document.getElementById('authSignOutBtn');
  if(oldSignOutBtn) oldSignOutBtn.addEventListener('click', handleSignOut);
  if(newSignOutBtn) newSignOutBtn.addEventListener('click', handleSignOut);
