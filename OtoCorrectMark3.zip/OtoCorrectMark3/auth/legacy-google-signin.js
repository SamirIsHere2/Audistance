  // ---------------- Google sign-in (session-only, no backend) ----------------
  const signInBtn      = document.getElementById('signInBtn');
  const authChip       = document.getElementById('authChip');
  const authAvatar     = document.getElementById('authAvatar');
  const authName       = document.getElementById('authName');
  const authSignOutBtn = document.getElementById('authSignOutBtn');
  const googleModal    = document.getElementById('googleModal');
  const googleModalClose    = document.getElementById('googleModalClose');
  const googleClientIdInput = document.getElementById('googleClientIdInput');
  const googleClientIdSubmit= document.getElementById('googleClientIdSubmit');
  const googleBtnContainer  = document.getElementById('googleBtnContainer');

  let googleScriptLoaded = false;
  function loadGoogleScript(cb){
    if(googleScriptLoaded && window.google && window.google.accounts){ cb(); return; }
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true; s.defer = true;
    s.onload = () => { googleScriptLoaded = true; cb(); };
    document.head.appendChild(s);
  }

  function decodeJwt(token){
    try{
      const payload = token.split('.')[1];
      const json = decodeURIComponent(
        atob(payload.replace(/-/g,'+').replace(/_/g,'/'))
          .split('').map(c => '%' + ('00'+c.charCodeAt(0).toString(16)).slice(-2)).join('')
      );
      return JSON.parse(json);
    }catch(e){ return null; }
  }

  function handleCredentialResponse(response){
    const data = decodeJwt(response.credential);
    if(!data) return;
    authName.textContent  = data.name || data.email || 'Signed in';
    authAvatar.src        = data.picture || '';
    signInBtn.style.display  = 'none';
    authChip.style.display   = 'flex';
    googleModal.classList.remove('show');
  }
  window.handleCredentialResponse = handleCredentialResponse;

  signInBtn.addEventListener('click', () => googleModal.classList.add('show'));
  googleModalClose.addEventListener('click', () => googleModal.classList.remove('show'));

  googleClientIdSubmit.addEventListener('click', () => {
    const id = googleClientIdInput.value.trim();
    if(!id) return;
    loadGoogleScript(() => {
      try{
        google.accounts.id.initialize({ client_id: id, callback: handleCredentialResponse });
        googleBtnContainer.innerHTML = '';
        google.accounts.id.renderButton(googleBtnContainer, { theme:'outline', size:'large', width:320 });
      }catch(e){
        googleBtnContainer.textContent = 'Could not initialise Google sign-in with that Client ID.';
      }
    });
  });

  authSignOutBtn.addEventListener('click', () => {
    if(window.google && google.accounts){ try{ google.accounts.id.disableAutoSelect(); }catch(e){} }
    authChip.style.display  = 'none';
    signInBtn.style.display = 'inline-block';
  });

  // Also wire the old sign-out button if it still exists in the DOM
  const oldSignOutBtn = document.getElementById('signOutBtn');
  if(oldSignOutBtn) oldSignOutBtn.addEventListener('click', () => authSignOutBtn.click());

