  // ---------------- face detection loop ----------------
  let ctx = null;
  let lastFace = null;
  let missCount = 0;
  let modelsReady = false;
  let detecting = false;

  startBtn.addEventListener('click', startCamera);

  const MODEL_URL = 'https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@master/weights';

  function startCamera(){
    statusText.textContent = 'Requesting camera…';
    navigator.mediaDevices.getUserMedia({ video: { width:640, height:480, facingMode:'user' }, audio:false })
      .then(stream => {
        video.srcObject = stream;
        stageMsg.style.display = 'none';
        return video.play();
      })
      .then(() => {
        overlay.width = video.videoWidth || 640;
        overlay.height = video.videoHeight || 480;
        ctx = overlay.getContext('2d');
        statusText.textContent = 'Loading face detector…';
        return loadModels();
      })
      .then(() => {
        modelsReady = true;
        statusText.textContent = 'Looking for a face…';
        requestAnimationFrame(drawLoop);
        detectTick();
      })
      .catch(err => {
        console.error(err);
        if(!modelsReady && video.srcObject){
          statusText.textContent = 'Face detector failed to load.';
          readoutText.textContent = 'Check your network connection (the detection model loads from a CDN) and reload the page.';
        } else {
          statusText.textContent = 'Camera access was blocked.';
          readoutText.textContent = 'Allow camera permission in your browser settings and reload the page.';
        }
      });
  }

  function loadModels(){
    return Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL)
    ]);
  }

  async function detectTick(){
    if(!modelsReady) return;
    if(video.readyState >= 2 && !detecting){
      detecting = true;
      try{
        const opts = new faceapi.TinyFaceDetectorOptions({
          inputSize: 320,
          scoreThreshold: parseFloat(sensSlider.value)
        });
        const result = await faceapi.detectSingleFace(video, opts);
        if(result && result.box && result.box.width > 20){
          lastFace = result.box;
          missCount = 0;
        } else {
          missCount++;
          if(missCount > 6) lastFace = null;
        }
      } catch(e){
        console.error('detection error', e);
      }
      detecting = false;
    }
    setTimeout(detectTick, 120);
  }

  function statusColorFor(dot, ok){
    dot.style.background = ok ? GREEN : RED;
  }

  function drawLoop(){
    requestAnimationFrame(drawLoop);
    if(!ctx) return;
    ctx.clearRect(0,0,overlay.width, overlay.height);

    if(!lastFace){
      statusDot.style.background = RED;
      statusText.textContent = 'No face detected';
      readoutText.textContent = 'Face the camera directly, with your face taking up a good part of the frame, in decent light.';
      [dotDistance,dotH,dotV,dotLight].forEach(d => d.style.background = RED);
      valDistance.textContent = '— cm';
      valH.textContent = '—'; valV.textContent = '—'; valLight.textContent = '—';
      if(volumeFeatureOn) volReadout.textContent = 'vol —';
      if(spotifyFeatureOn) spotifyVolReadout.textContent = 'vol —';
      return;
    }

    const f = lastFace;
    const vw = overlay.width, vh = overlay.height;

    const faceCenterX = vw - (f.x + f.width/2);
    const faceCenterY = f.y + f.height/2;

    const distanceCm = (AVG_FACE_WIDTH_CM * ASSUMED_FOCAL_PX) / f.width;
    const [minCm, maxCm] = rangeCm();
    const distOk = distanceCm >= minCm && distanceCm <= maxCm;
    const displayDist = unit === 'ft' ? (distanceCm/30.48).toFixed(1)+' ft' : Math.round(distanceCm)+' cm';
    valDistance.textContent = displayDist;
    statusColorFor(dotDistance, distOk);
    hintDistance.textContent = distOk ? 'In range' : (distanceCm < minCm ? 'Move farther away' : 'Move closer');

    if(volumeFeatureOn && gainNode){
      const level = volumeForDistance(distanceCm);
      gainNode.gain.setTargetAtTime(level, audioCtx.currentTime, 0.15);
      volReadout.textContent = '~' + Math.round(dbForDistance(distanceCm)) + ' dB';
    }
    if(spotifyFeatureOn && spotifyAccessToken){
      const level = volumeForDistance(distanceCm);
      const pct = Math.round(level*100);
      spotifyVolReadout.textContent = 'vol ' + pct + '%';
      setSpotifyVolume(pct);
    }

    const hOffset = (faceCenterX - vw/2) / (vw/2);
    const hOk = Math.abs(hOffset) < 0.18;
    valH.textContent = (hOffset*100).toFixed(0)+'%';
    statusColorFor(dotH, hOk);
    hintH.textContent = hOk ? 'Centered' : (hOffset < 0 ? 'Shift right' : 'Shift left');

    const vOffset = (faceCenterY - vh/2) / (vh/2);
    const vOk = Math.abs(vOffset) < 0.2;
    valV.textContent = (vOffset*100).toFixed(0)+'%';
    statusColorFor(dotV, vOk);
    hintV.textContent = vOk ? 'Centered' : (vOffset < 0 ? 'Raise camera' : 'Lower camera');

    let brightness = 128;
    try{
      const tmp = document.createElement('canvas');
      tmp.width = Math.max(1,Math.round(f.width));
      tmp.height = Math.max(1,Math.round(f.height));
      const tctx = tmp.getContext('2d');
      tctx.drawImage(video, vw - f.x - f.width, f.y, f.width, f.height, 0, 0, tmp.width, tmp.height);
      const data = tctx.getImageData(0,0,tmp.width,tmp.height).data;
      let sum = 0, count = 0;
      for(let i=0;i<data.length;i+=16){
        sum += (data[i]+data[i+1]+data[i+2])/3;
        count++;
      }
      brightness = count ? sum/count : 128;
    } catch(e){ /* ignore, cross-origin canvas safety */ }
    const lightOk = brightness > 75 && brightness < 205;
    valLight.textContent = Math.round(brightness);
    statusColorFor(dotLight, lightOk);
    hintLight.textContent = lightOk ? 'Good lighting' : (brightness <= 75 ? 'Too dark' : 'Too bright');

    const allOk = distOk && hOk && vOk && lightOk;
    statusDot.style.background = allOk ? GREEN : (distOk ? AMBER : RED);
    statusText.textContent = allOk ? 'Optimal position' : 'Adjusting…';
    readoutText.textContent = 'distance ' + Math.round(distanceCm) + 'cm · target ' + Math.round(minCm) + '-' + Math.round(maxCm) + 'cm';

    const boxColor = allOk ? GREEN : (distOk ? AMBER : RED);
    ctx.save();
    ctx.strokeStyle = boxColor;
    ctx.lineWidth = 2;
    ctx.strokeRect(vw - f.x - f.width, f.y, f.width, f.height);

    const cx = faceCenterX, cy = faceCenterY;
    const t = performance.now()/1000;
    for(let i=0;i<3;i++){
      const phase = (t*0.6 + i/3) % 1;
      const r = (f.width/1.3) * (0.9 + phase*0.9);
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI*2);
      ctx.strokeStyle = boxColor;
      ctx.globalAlpha = (1-phase) * 0.5;
      ctx.lineWidth = 2;
      ctx.stroke();
    }
    ctx.restore();
  }

  // ================= SOUND CORRECTOR =================
  const EQ_BANDS = [
    { freq: 125,  label: '125Hz'  },
    { freq: 350,  label: '350Hz'  },
    { freq: 1000, label: '1kHz'   },
    { freq: 2000, label: '2kHz'   },
    { freq: 4000, label: '4kHz'   },
    { freq: 8000, label: '8kHz'   }
  ];
  const eqBandsEl = document.getElementById('eqBands');
  const eqSliders = [];
  EQ_BANDS.forEach((b, i) => {
    const wrap = document.createElement('div');
    wrap.className = 'eq-band';
    wrap.innerHTML =
      '<span class="eq-val" id="eqVal'+i+'">0dB</span>' +
      '<input type="range" min="-12" max="12" step="1" value="0" id="eqSlider'+i+'">' +
      '<label>'+b.label+'</label>';
    eqBandsEl.appendChild(wrap);
    const input = wrap.querySelector('input');
    const valSpan = wrap.querySelector('.eq-val');
    input.addEventListener('input', () => {
      valSpan.textContent = (input.value > 0 ? '+' : '') + input.value + 'dB';
      if(eqFilters[i]) eqFilters[i].gain.setTargetAtTime(parseFloat(input.value), soundCtx().currentTime, 0.05);
    });
    eqSliders.push(input);
  });

  const PRESETS = {
    flat:   [0,0,0,0,0,0],
    speech: [-3,2,5,6,3,-1],
    highs:  [-4,-2,0,3,7,9],
    warm:   [3,2,0,-2,-4,-6]
  };
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const vals = PRESETS[btn.getAttribute('data-preset')];
      vals.forEach((v,i) => {
        eqSliders[i].value = v;
        eqSliders[i].dispatchEvent(new Event('input'));
      });
    });
  });

  let soundAudioCtx = null;
  let eqFilters = [];
  let eqInputGain = null;
  let currentSourceNode = null;
  let currentSourceType = 'noise';
  let soundPlaying = false;

