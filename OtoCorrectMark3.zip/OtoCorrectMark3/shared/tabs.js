  // ---------------- tabs ----------------
  const tabs = {
    home:        document.getElementById('tabHome'),
    distance:    document.getElementById('tabDistance'),
    sound:       document.getElementById('tabSound'),
    test:        document.getElementById('tabTest'),
    connections: document.getElementById('tabConnections')
  };
  const views = {
    home:        document.getElementById('view-home'),
    distance:    document.getElementById('view-distance'),
    sound:       document.getElementById('view-sound'),
    test:        document.getElementById('view-test'),
    connections: document.getElementById('view-connections')
  };
  function showView(name){
    Object.keys(views).forEach(k => {
      views[k].classList.toggle('active', k === name);
      tabs[k].classList.toggle('active', k === name);
    });
  }
  Object.keys(tabs).forEach(k => tabs[k].addEventListener('click', () => showView(k)));

  // decorative hero equalizer bars
  (function buildHeroEqBars(){
    const container = document.getElementById('heroEqBars');
    if(!container) return;
    const count = 22;
    for(let i=0;i<count;i++){
      const bar = document.createElement('span');
      const h = 14 + Math.random()*46;
      const dur = (1.1 + Math.random()*1.3).toFixed(2);
      const delay = (Math.random()*1.4).toFixed(2);
      bar.style.height = h + 'px';
      bar.style.animationDuration = dur + 's';
      bar.style.animationDelay = '-' + delay + 's';
      container.appendChild(bar);
    }
  })();
  document.getElementById('heroStart').addEventListener('click', () => showView('distance'));
  document.getElementById('heroTest').addEventListener('click', () => showView('test'));
  document.querySelectorAll('[data-goto]').forEach(btn => {
    btn.addEventListener('click', () => showView(btn.getAttribute('data-goto')));
  });

